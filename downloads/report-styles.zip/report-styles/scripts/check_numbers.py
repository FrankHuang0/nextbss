"""Check that every number on the slides can be traced back to the source data.

Usage: python numbers.py <report.html> <source1> [source2 ...]
  Sources are text files (md / csv / json / txt). Save Excel as csv first.

For each number on each slide prints one line:
  ✔  found in a source  (file:line); numbers <= 10 get a "may be coincidence" note
  ≈  not in the source, but the same block shows a formula (e.g. "204 / 222")
  ?  not found and no formula -> fix the number, or write the formula next to it
Exit 1 means there are "?" lines to look at (not necessarily wrong).
Mark an element with data-nocheck to skip it (e.g. page numbers).
"""
import re, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

TOKEN = r"#\d+|\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?"
FORMULA = re.compile(r"\d[\d,.]*\s*[/÷×*+]\s*\d")

EXTRACT_JS = r"""(TOKEN) => {
  const out = [];
  document.querySelectorAll('.slide').forEach((s, i) => {
    const w = document.createTreeWalker(s, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const el = n.parentElement;
      if (!el || el.closest('style,script,[data-nocheck]')) continue;
      const t = n.textContent;
      const re = new RegExp(TOKEN, 'g');
      let m;
      const box = (el.parentElement && el.parentElement.parentElement) || el;
      const ctx = box.textContent.replace(/\s+/g, ' ').slice(0, 400);
      while ((m = re.exec(t))) out.push({page: i + 1, tok: m[0], ctx});
    }
  });
  return out;
}"""


def norm(tok):
    if tok.startswith("#"):
        return ("id", tok[1:])
    d = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", tok)
    if d:
        return ("date", tuple(int(x) for x in d.groups()))
    v = float(tok.replace(",", ""))
    return ("num", v)


def index_sources(paths):
    idx = {}
    for p in paths:
        for ln, line in enumerate(Path(p).read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            for m in re.finditer(TOKEN, line):
                if m.start() > 0 and line[m.start() - 1].isdigit():
                    continue
                idx.setdefault(norm(m.group()), f"{Path(p).name}:{ln}")
    return idx


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    sys.stdout.reconfigure(encoding="utf-8")
    html, sources = Path(sys.argv[1]), sys.argv[2:]
    idx = index_sources(sources)
    with sync_playwright() as p:
        try:
            b = p.chromium.launch(channel="msedge")
        except Exception:
            b = p.chromium.launch()
        pg = b.new_page()
        pg.goto(html.resolve().as_uri())
        pg.wait_for_load_state("networkidle")
        items = pg.evaluate(EXTRACT_JS, TOKEN)
        b.close()
    seen, unknown = set(), 0
    for it in items:
        key = (it["page"], it["tok"])
        if key in seen:
            continue
        seen.add(key)
        n = norm(it["tok"])
        if n in idx:
            small = n[0] == "num" and n[1] <= 10
            print(f"p{it['page']}  ✔ {it['tok']}  {idx[n]}" + ("（小數字，可能只是巧合對到；若是推算請寫算式）" if small else ""))
        elif FORMULA.search(it["ctx"]):
            print(f"p{it['page']}  ≈ {it['tok']}  推算（旁邊有算式）")
        else:
            unknown += 1
            print(f"p{it['page']}  ? {it['tok']}  找不到 → 改正；若是推算，在旁邊寫算式（例：204 / 222）  …{it['ctx'][:40]}")
    print(f"\n共 {len(seen)} 個數字：? 待確認 {unknown} 個")
    sys.exit(1 if unknown else 0)


if __name__ == "__main__":
    main()
