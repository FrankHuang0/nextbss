"""Editable PPTX: each slide = background picture WITHOUT text + real PowerPoint text boxes on top.

Used by build.py --pptx. Text inside <svg> stays in the picture (not editable).
Mark an element with data-noedit to keep its text in the picture too.
"""
import json, re, subprocess
from pathlib import Path

PX = 7620          # EMU per CSS px (1600 px slide = 12192000 EMU)
PT = 0.6           # pt per CSS px

EXTRACT_JS = r"""() => {
  const slides = [...document.querySelectorAll('.slide')];
  const rot = el => { const t = getComputedStyle(el).transform; if (!t || t === 'none') return 0; const m = new DOMMatrix(t); return Math.atan2(m.b, m.a); };
  const angleOf = (el, slide) => { let a = 0; for (let e = el; e && e !== slide.parentElement; e = e.parentElement) a += rot(e); return a; };
  const isInline = el => { const d = getComputedStyle(el).display; return d === 'inline' || d === 'contents'; };
  const visible = el => !el.checkVisibility || el.checkVisibility({opacityProperty: true, visibilityProperty: true});
  const style = el => { const c = getComputedStyle(el); const d = c.textDecorationLine || '';
    return {font: c.fontFamily, size: parseFloat(c.fontSize), weight: parseInt(c.fontWeight) || 400, italic: c.fontStyle !== 'normal',
            color: c.webkitTextFillColor && c.webkitTextFillColor !== c.color && !/rgba\(0, 0, 0, 0\)/.test(c.webkitTextFillColor) ? c.webkitTextFillColor : c.color,
            ls: c.letterSpacing === 'normal' ? 0 : parseFloat(c.letterSpacing) || 0, upper: c.textTransform === 'uppercase',
            u: d.includes('underline'), s: d.includes('line-through')}; };

  // pass A: block centres with rotation in place
  const result = [];
  const perSlide = slides.map(slide => {
    const blocks = new Map();
    const w = document.createTreeWalker(slide, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const p = n.parentElement;
      if (!p || p.closest('svg,style,script,[data-noedit]') || !visible(p)) continue;
      let b = p; while (b !== slide && isInline(b)) b = b.parentElement;
      if (!blocks.has(b)) blocks.set(b, {nodes: [], angle: angleOf(b, slide), A: b.getBoundingClientRect()});
      blocks.get(b).nodes.push(n);
    }
    return blocks;
  });

  // pass B: measure with rotations switched off
  const undo = [];
  slides.forEach(s => s.querySelectorAll('*').forEach(e => { if (Math.abs(rot(e)) > 1e-4) { undo.push([e, e.style.getPropertyValue('transform'), e.style.getPropertyPriority('transform')]); e.style.setProperty('transform', 'none', 'important'); } }));
  const range = document.createRange();
  slides.forEach((slide, si) => {
    const S = slide.getBoundingClientRect();
    const out = [];
    for (const [b, info] of perSlide[si]) {
      const chars = [];
      for (const node of info.nodes) {
        const t = node.textContent, st = style(node.parentElement);
        for (let i = 0; i < t.length;) {
          const len = t.codePointAt(i) > 0xffff ? 2 : 1;
          range.setStart(node, i); range.setEnd(node, i + len);
          const rs = range.getClientRects(), ch = t.slice(i, i + len); i += len;
          if (!rs.length) continue;
          const q = rs[rs.length - 1];
          if (q.width < 0.5 || q.height < 0.5) continue;
          chars.push({ch: st.upper ? ch.toUpperCase() : ch.replace(/\s/, ' '), st, l: q.left, t: q.top, r: q.right, b: q.bottom});
        }
      }
      if (!chars.some(c => c.ch.trim())) continue;
      const lines = [];
      let q0 = null;
      for (const c of chars) {
        const L = lines[lines.length - 1];
        // new line = text jumps back to the left and down (works even when tight lines overlap)
        const wrap = q0 && c.l < q0.r - Math.max(2, c.st.size * 0.3) && c.t + c.b > q0.t + q0.b;
        if (!L || wrap || c.t >= L.b) lines.push({runs: [], l: c.l, t: c.t, r: c.r, b: c.b});
        q0 = c;
        const M = lines[lines.length - 1];
        M.l = Math.min(M.l, c.l); M.r = Math.max(M.r, c.r); M.t = Math.min(M.t, c.t); M.b = Math.max(M.b, c.b);
        // a visible gap (inline margin/padding) after the previous char -> give that char extra letter-spacing
        const pv = M.prev, gap = pv ? c.l - pv.r : 0;
        if (pv && gap > 1.5) {
          const z = M.runs[M.runs.length - 1];
          z.text = z.text.slice(0, z.text.length - pv.ch.length);
          if (!z.text) M.runs.pop();
          M.runs.push({key: 'gap' + Math.random(), text: pv.ch, st: {...pv.st, ls: pv.st.ls + gap}});
        }
        M.prev = c;
        const last = M.runs[M.runs.length - 1], key = JSON.stringify(c.st);
        if (last && last.key === key) last.text += c.ch; else M.runs.push({key, text: c.ch, st: c.st});
      }
      for (const L of lines) {
        L.runs[0].text = L.runs[0].text.replace(/^ +/, ''); const z = L.runs[L.runs.length - 1]; z.text = z.text.replace(/ +$/, '');
        L.runs = L.runs.filter(r => r.text).map(r => ({text: r.text, ...r.st}));
      }
      const B = b.getBoundingClientRect(), cs = getComputedStyle(b);
      const U = {l: Math.min(...lines.map(L => L.l)), r: Math.max(...lines.map(L => L.r)), t: lines[0].t, b: lines[lines.length - 1].b};
      const a = info.angle, dx = (U.l + U.r) / 2 - (B.left + B.width / 2), dy = (U.t + U.b) / 2 - (B.top + B.height / 2);
      const cx = info.A.left + info.A.width / 2 + dx * Math.cos(a) - dy * Math.sin(a) - S.left;
      const cy = info.A.top + info.A.height / 2 + dx * Math.sin(a) + dy * Math.cos(a) - S.top;
      const align = {center: 'center', right: 'right', end: 'right'}[cs.textAlign] || 'left';
      const pitch = lines.length > 1 ? (lines[lines.length - 1].t - lines[0].t) / (lines.length - 1) : null;
      const lh = parseFloat(cs.lineHeight);
      out.push({cx, cy, w: U.r - U.l, h: U.b - U.t, angle: a * 180 / Math.PI, align, pitch, lh: isNaN(lh) ? null : lh,
                lines: lines.map(L => ({runs: L.runs, h: L.b - L.t, l: L.l - U.l, r: U.r - L.r}))});
    }
    result.push(out);
  });
  undo.forEach(([e, v, p]) => v ? e.style.setProperty('transform', v, p) : e.style.removeProperty('transform'));

  // hide text but keep every non-text colour (borders, icons, bullets) exactly as it was
  const props = ['border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color', 'outline-color', 'background-color', 'box-shadow', 'fill', 'stroke', 'column-rule-color'];
  const freeze = [], rules = [];
  let id = 0;
  slides.forEach(s => [s, ...s.querySelectorAll('*')].forEach(e => {
    const c = getComputedStyle(e);
    freeze.push([e, props.map(p => [p, c.getPropertyValue(p)])]);
    if (e.closest('svg')) freeze.push([e, [['color', c.color]]]);
    for (const ps of ['::before', '::after', '::marker']) {
      const pc = getComputedStyle(e, ps);
      if (ps !== '::marker' && (pc.content === 'none' || pc.content === 'normal')) continue;
      if (!e.dataset.ppx) e.dataset.ppx = ++id;
      rules.push(`[data-ppx="${e.dataset.ppx}"]${ps}{color:${pc.color}!important;-webkit-text-fill-color:${pc.color}!important;` +
        props.map(p => `${p}:${pc.getPropertyValue(p)}!important`).join(';') + '}');
    }
  }));
  freeze.forEach(([e, kv]) => kv.forEach(([k, v]) => e.style.setProperty(k, v, 'important')));
  const keep = [...document.querySelectorAll('.slide svg, .slide [data-noedit]')];
  keep.forEach(e => { const c = getComputedStyle(e).color; e.dataset.ppkeep = c; });
  const st = document.createElement('style');
  st.textContent = `.slide, .slide *:not(svg):not(svg *) { color: transparent !important; -webkit-text-fill-color: transparent !important; text-shadow: none !important; text-decoration-color: transparent !important; }
` + keep.map((e, i) => { e.dataset.ppk = i; return `[data-ppk="${i}"], [data-ppk="${i}"] * { color: ${e.dataset.ppkeep} !important; -webkit-text-fill-color: ${e.dataset.ppkeep} !important; }`; }).join('\n') + '\n' + rules.join('\n');
  document.head.appendChild(st);
  return result;
}"""

CJK = {"Noto Sans TC", "Noto Serif TC", "Noto Sans HK", "Noto Serif HK", "Microsoft JhengHei", "Microsoft JhengHei UI",
       "DFKai-SB", "標楷體", "PMingLiU", "新細明體", "MingLiU"}
GENERIC = {"sans-serif": "Microsoft JhengHei", "serif": "Noto Serif TC", "monospace": "Consolas", "cursive": "Ink Free",
           "system-ui": "Microsoft JhengHei"}
WEIGHT = {900: ["Black", "Heavy", "ExtraBold"], 800: ["ExtraBold", "Black"], 600: ["SemiBold", "Semibold", "DemiBold", "Semib"],
          500: ["Medium"], 300: ["Light", "DemiLight", "SemiLight"], 200: ["ExtraLight", "Light"], 100: ["Thin", "ExtraLight"]}
_fonts = None


def installed():
    global _fonts
    if _fonts is None:
        try:
            out = subprocess.run(["powershell", "-NoProfile", "-Command",
                                  "[Console]::OutputEncoding=[Text.Encoding]::UTF8; Add-Type -AssemblyName System.Drawing; "
                                  "([System.Drawing.Text.InstalledFontCollection]::new()).Families.Name"],
                                 capture_output=True, timeout=60).stdout.decode("utf-8", "replace")
            _fonts = {x.strip() for x in out.splitlines() if x.strip()}
        except Exception:
            _fonts = set()
    return _fonts


def pick_font(stack, weight):
    names = [x.strip().strip("'\"") for x in stack.split(",")]
    have = installed()
    ok = lambda n: not have or n in have or n in GENERIC.values()
    fams = [GENERIC.get(n, n) for n in names]
    latin = next((f for f in fams if ok(f)), "Microsoft JhengHei")
    ea = next((f for f in fams if f in CJK and ok(f)), "Microsoft JhengHei")
    bold = weight >= 600

    def variant(base):
        w = min(WEIGHT, key=lambda k: abs(k - weight)) if weight not in (400, 700) else None
        for suf in WEIGHT.get(w, []):
            n = f"{base} {suf}"[:31]
            if n in have:
                return n, False
        return base, bold
    latin, b1 = variant(latin)
    ea, b2 = variant(ea)
    return latin, ea, b1 or b2


# Measured (one paragraph per line, exact spacing): PowerPoint draws text lower than Chrome by
#   0.25*L + c*size      (L = line pitch px; error <= 3px at 80px, L/size 0.8-2.4, any weight)
# Values: font -> (c, T). T is only used to pick a safe spacing for one-line boxes.
CAL = {"Noto Sans TC": (-0.42, 0.95), "Noto Serif TC": (-0.42, 0.95), "Noto Sans HK": (-0.42, 0.95),
       "Noto Serif HK": (-0.42, 0.95), "Noto Serif": (-0.385, 0.9), "Segoe UI": (-0.405, 0.85),
       "Microsoft JhengHei": (-0.405, 0.85), "Bahnschrift": (-0.285, 0.6), "DFKai-SB": (-0.30, 0.6),
       "Ink Free": (-0.29, 0.8), "Consolas": (-0.33, 0.75), "Cascadia": (-0.35, 0.75)}


def cal_for(font):
    key = max((k for k in CAL if font.startswith(k)), key=len, default="Segoe UI")
    return CAL[key]


def drop(pitch, size, font):
    c, T = cal_for(font)
    return 0.25 * pitch + c * size


def rgba(s):
    m = re.findall(r"[\d.]+", s)
    if len(m) < 3:
        return "000000", 1.0
    return "".join(f"{round(float(x)):02X}" for x in m[:3]), float(m[3]) if len(m) > 3 else 1.0


def add_slide(prs, img, blocks):
    from pptx.util import Emu, Pt
    from pptx.enum.text import PP_ALIGN, MSO_AUTO_SIZE, MSO_ANCHOR
    from pptx.oxml.ns import qn
    from lxml import etree
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    sl.shapes.add_picture(str(img), 0, 0, prs.slide_width, prs.slide_height)
    for bl in blocks:
        n = len(bl["lines"])
        big = max(r["size"] for L in bl["lines"] for r in L["runs"])
        head = max(bl["lines"][0]["runs"], key=lambda r: r["size"])
        size, font = head["size"], pick_font(head["font"], 400)[0]
        T = cal_for(font)[1]
        if n == 1:   # spacing is invisible for one line: keep it clear of PowerPoint's jump zone
            pitch = max(bl["lh"] or bl["h"], (T + 0.2) * size)
        else:
            pitch = bl["pitch"]
        slack = big * 1.2
        w = bl["w"] + slack * (2 if bl["align"] == "center" else 1)
        h = pitch * n
        left = bl["cx"] - bl["w"] / 2 - (slack if bl["align"] == "right" else slack if bl["align"] == "center" else 0)
        top = bl["cy"] - h / 2 - drop(pitch, size, font)
        tb = sl.shapes.add_textbox(Emu(round(left * PX)), Emu(round(top * PX)), Emu(round(w * PX)), Emu(round(h * PX)))
        tb.rotation = bl["angle"]
        tf = tb.text_frame
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.word_wrap, tf.auto_size, tf.vertical_anchor = True, MSO_AUTO_SIZE.NONE, MSO_ANCHOR.TOP
        align = {"center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT}.get(bl["align"], PP_ALIGN.LEFT)
        for i, L in enumerate(bl["lines"]):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()   # one paragraph per line keeps per-line indents
            p.alignment, p.line_spacing = align, Pt(pitch * PT)
            p.space_before = p.space_after = 0
            pPr = p._p.get_or_add_pPr()
            if bl["align"] == "left" and L["l"] > 1:
                pPr.set("marL", str(round(L["l"] * PX)))
            if bl["align"] == "right" and L["r"] > 1:
                pPr.set("marR", str(round(L["r"] * PX)))
            for r in L["runs"]:
                run = p.add_run()
                run.text = r["text"]
                f = run.font
                latin, ea, bold = pick_font(r["font"], r["weight"])
                f.name, f.size, f.bold, f.italic = latin, Pt(round(r["size"] * PT * 2) / 2), bold, r["italic"]
                if r["u"]:
                    f.underline = True
                hexc, alpha = rgba(r["color"])
                f.color.rgb = __import__("pptx.dml.color", fromlist=["RGBColor"]).RGBColor.from_string(hexc)
                rPr = run._r.get_or_add_rPr()
                if alpha < 1:
                    clr = rPr.find(qn("a:solidFill")).find(qn("a:srgbClr"))
                    etree.SubElement(clr, qn("a:alpha")).set("val", str(round(alpha * 100000)))
                if r["ls"]:
                    rPr.set("spc", str(round(r["ls"] * PT * 100)))
                if r["s"]:
                    rPr.set("strike", "sngStrike")
                ea_el = rPr.find(qn("a:ea"))
                if ea_el is None:
                    ea_el = etree.SubElement(rPr, qn("a:ea"))
                ea_el.set("typeface", ea)
    return sl


def export(browser, html: Path, dest: Path, tmp: Path):
    from pptx import Presentation
    from pptx.util import Emu
    pg = browser.new_page(viewport={"width": 1664, "height": 1000}, device_scale_factor=2)
    pg.goto(html.resolve().as_uri())
    pg.wait_for_load_state("networkidle")
    pg.evaluate("document.fonts.ready")
    data = pg.evaluate(EXTRACT_JS)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)
    for i, (s, blocks) in enumerate(zip(pg.query_selector_all(".slide"), data), 1):
        img = tmp / f"bg-{i:02d}.png"
        s.screenshot(path=str(img))
        add_slide(prs, img, blocks)
    pg.close()
    prs.save(dest)
    return sum(len(b) for b in data)
