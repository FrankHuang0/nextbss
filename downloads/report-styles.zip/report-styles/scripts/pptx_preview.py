"""Render a PPTX to PNG with the locally installed PowerPoint, to check the editable PPTX by eye.

Usage: python pptx_preview.py <deck.pptx> [--out DIR]
  Writes DIR/<stem>-pptx-NN.png (default DIR: <pptx dir>/previews) and DIR/_sheet-<stem>-pptx.png.
  Needs Microsoft PowerPoint (Windows). Without it, exits 2 and prints a note.
"""
import argparse, subprocess, sys
from pathlib import Path

PS = r"""
$ErrorActionPreference = 'Stop'
$app = New-Object -ComObject PowerPoint.Application
try {
  $p = $app.Presentations.Open('{src}', -1, 0, 0)
  $i = 0
  foreach ($s in $p.Slides) { $i++; $s.Export(('{out}\{stem}-pptx-{0:D2}.png' -f $i), 'PNG', 1600, 900) }
  $p.Close()
} finally { $app.Quit() }
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx", type=Path)
    ap.add_argument("--out", type=Path)
    a = ap.parse_args()
    src = a.pptx.resolve()
    out = (a.out or src.parent / "previews").resolve()
    out.mkdir(parents=True, exist_ok=True)
    for old in out.glob(f"{src.stem}-pptx-*.png"):
        old.unlink()
    ps = PS.replace("{src}", str(src).replace("'", "''")).replace("{out}", str(out).replace("'", "''")).replace("{stem}", src.stem)
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True)
    sys.stdout.reconfigure(encoding="utf-8")
    shots = sorted(out.glob(f"{src.stem}-pptx-*.png"))
    if r.returncode or not shots:
        print("找不到 PowerPoint 或轉圖失敗，請直接用 PowerPoint 打開檢查。\n" + r.stderr[-400:])
        sys.exit(2)
    sys.path.insert(0, str(Path(__file__).parent))
    from build import contact_sheet
    sheet = out / f"_sheet-{src.stem}-pptx.png"
    contact_sheet(shots, sheet, f"{src.stem}-pptx")
    print("\n".join(str(s) for s in shots + [sheet]))


if __name__ == "__main__":
    main()
