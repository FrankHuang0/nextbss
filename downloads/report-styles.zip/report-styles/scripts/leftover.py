"""List text in an output report that is identical to text in the style template.

Usage: python leftover.py <output.html> <template.html> [--min 6]

Every listed line is a possible leftover from the template. Keep it only if the
new data really says exactly the same thing; otherwise rewrite it.
Exit code 0 when nothing matches, 1 when there are matches to review.
"""
import argparse
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

SKIP = {"style", "script", "svg", "defs", "symbol"}


class TextCollector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.depth_skip = 0
        self.in_slide = 0
        self.slide = ""
        self.items = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in SKIP:
            self.depth_skip += 1
        if tag == "section" and "slide" in (a.get("class") or "").split():
            self.in_slide += 1
            self.slide = a.get("data-name") or f"slide{len(self.items)}"

    def handle_endtag(self, tag):
        if tag in SKIP and self.depth_skip:
            self.depth_skip -= 1
        if tag == "section" and self.in_slide:
            self.in_slide -= 1

    def handle_data(self, data):
        if self.depth_skip or not self.in_slide:
            return
        text = re.sub(r"\s+", " ", data).strip()
        if text:
            self.items.append((self.slide, text))


def collect(path):
    p = TextCollector()
    p.feed(Path(path).read_text(encoding="utf-8"))
    return p.items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("output")
    ap.add_argument("template")
    ap.add_argument("--min", type=int, default=6, help="minimum characters (default 6)")
    args = ap.parse_args()

    template_texts = {t for _, t in collect(args.template) if len(t) >= args.min}
    hits = [(s, t) for s, t in collect(args.output) if t in template_texts]

    sys.stdout.reconfigure(encoding="utf-8")
    for slide, text in hits:
        print(f"[{slide}] {text}")
    print(f"--- {len(hits)} 筆和樣板相同（≥{args.min} 字）")
    return 1 if hits else 0


if __name__ == "__main__":
    sys.exit(main())
