"""Render report-styles decks to PNG, check layout, optionally export PPTX / PDF.

Usage:
  python build.py deck.html [more.html ...] [--pptx] [--pdf] [--out DIR]

  - Every <section class="slide" data-name="..."> becomes DIR/<stem>-<name>.png (default DIR: <html dir>/previews)
  - Also writes DIR/_sheet-<stem>.png: all slides as numbered thumbnails on one image.
  - Prints a JSON report:
      slides: per-slide issues — text outside the slide, clipped text, text spilling past its box
              (tile/panel/card) padding, overlapping text, U+FFFD (garbled) characters.
              Each size issue says how many px and a suggested fix.
      titles: each slide's action title in order (element with data-title, else the largest heading-like text).
  - Exit code 1 when any issue is found, so it can gate delivery.
  - --pptx writes an EDITABLE <stem>.pptx next to the HTML: background picture without text + real text boxes
    (see editable_pptx.py). Check it with pptx_preview.py.
  - --pptx-image writes <stem>-image.pptx as one full-bleed picture per slide (exact look, text not editable).
  - --pdf writes <stem>.pdf (one picture per page).
  - ailook: "looks AI-made" hints (filler words, glass blur, generic fonts) - a list to review, not a failure.
"""
import argparse, json, sys, tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

CHECK_JS = r"""
(slide) => {
  const sr = slide.getBoundingClientRect();
  const issues = [];
  const fix = (px) => px <= 20 ? '縮小間距或內距' : px <= 60 ? '縮短文字或字級降一階' : '拆成兩格／兩頁，或換更大的格子';
  const label = (el) => el.tagName + ' "' + el.textContent.trim().replace(/\s+/g, ' ').slice(0, 24) + '"';
  const visible = (el) => { const cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden' && +cs.opacity !== 0; };
  const isBox = (el) => {
    const cs = getComputedStyle(el);
    const bg = cs.backgroundColor !== 'rgba(0, 0, 0, 0)' && cs.backgroundColor !== 'transparent';
    const border = ['Top', 'Right', 'Bottom', 'Left'].filter(s => parseFloat(cs['border' + s + 'Width']) > 0).length >= 3;
    const r = el.getBoundingClientRect();
    return (bg || border || cs.backgroundImage !== 'none') && r.width >= 120 && r.height >= 60;
  };
  const lines = [];
  const walker = document.createTreeWalker(slide, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const el = n.parentElement;
    if (!n.textContent.trim() || !el || el.closest('svg, style, script') || !visible(el)) continue;
    const rg = document.createRange(); rg.selectNodeContents(n);
    const fs = parseFloat(getComputedStyle(el).fontSize);
    for (const c of rg.getClientRects()) {
      if (c.width <= 1 || c.height <= 1) continue;
      const gh = Math.min(c.height, fs * .8), top = c.top + (c.height - gh) / 2;  // glyph band, not the full line box
      lines.push({ r: { left: c.left, right: c.right, top, bottom: top + gh, width: c.width, height: gh }, el });
    }
  }
  const seen = new Set();
  for (const el of new Set(lines.map(l => l.el))) {
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    const tr = lines.filter(l => l.el === el).map(l => l.r);
    const t = { left: Math.min(...tr.map(x => x.left)), top: Math.min(...tr.map(x => x.top)), right: Math.max(...tr.map(x => x.right)), bottom: Math.max(...tr.map(x => x.bottom)) };
    if (t.right > sr.right + 1 || t.bottom > sr.bottom + 1 || t.left < sr.left - 1 || t.top < sr.top - 1)
      issues.push('outside slide: ' + label(el));
    if (el.clientWidth && cs.overflow !== 'visible' && el.scrollWidth > el.clientWidth + 2)
      issues.push(`clipped x ${el.scrollWidth - el.clientWidth}px: ${label(el)} → ${fix(el.scrollWidth - el.clientWidth)}`);
    if (el.clientHeight && cs.overflow !== 'visible' && el.scrollHeight > el.clientHeight + 2)
      issues.push(`clipped y ${el.scrollHeight - el.clientHeight}px: ${label(el)} → ${fix(el.scrollHeight - el.clientHeight)}`);
    let box = el.parentElement;
    let placed = getComputedStyle(el).position === 'absolute';  // labels deliberately placed on a border are fine
    while (box && box !== slide && !isBox(box)) { placed = placed || getComputedStyle(box).position === 'absolute'; box = box.parentElement; }
    if (!placed && box && box !== slide && box !== el && !seen.has(box)) {
      const bs = getComputedStyle(box), b = box.getBoundingClientRect();
      const inner = { left: b.left + parseFloat(bs.paddingLeft) * .4, right: b.right - parseFloat(bs.paddingRight) * .4,
                      top: b.top + parseFloat(bs.paddingTop) * .4, bottom: b.bottom - parseFloat(bs.paddingBottom) * .4 };
      const over = Math.round(Math.max(t.right - inner.right, t.bottom - inner.bottom, inner.left - t.left, inner.top - t.top));
      if (over > 2) { seen.add(box); issues.push(`spills into box padding ${over}px: ${label(el)} → ${fix(over)}`); }
    }
  }
  for (const box of slide.querySelectorAll('*')) {
    const cs = getComputedStyle(box);
    if (cs.overflow === 'visible' || !visible(box) || !box.textContent.trim() || box.closest('svg')) continue;
    const dy = box.scrollHeight - box.clientHeight, dx = box.scrollWidth - box.clientWidth;
    if ([...box.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) continue;  // own text handled above
    if (dy > 2) issues.push(`box content clipped y ${dy}px: ${label(box)} → ${fix(dy)}`);
    else if (dx > 2) issues.push(`box content clipped x ${dx}px: ${label(box)} → ${fix(dx)}`);
  }
  const contains = (a, b) => a.contains(b) || b.contains(a);
  const reported = new Set();
  for (let i = 0; i < lines.length; i++) for (let j = i + 1; j < lines.length; j++) {
    const A = lines[i], B = lines[j];
    if (A.el === B.el || contains(A.el, B.el)) continue;
    const w = Math.min(A.r.right, B.r.right) - Math.max(A.r.left, B.r.left);
    const h = Math.min(A.r.bottom, B.r.bottom) - Math.max(A.r.top, B.r.top);
    if (w <= 0 || h <= 0) continue;
    const small = Math.min(A.r.width * A.r.height, B.r.width * B.r.height);
    const key = label(A.el) + '|' + label(B.el);
    if (w * h > small * .2 && !reported.has(key)) { reported.add(key); issues.push(`text overlap: ${label(A.el)} × ${label(B.el)} → 移開其中一個，或改成不重疊的版面`); }
  }
  if (/\uFFFD/.test(slide.innerText)) issues.push('garbled text (U+FFFD) found');
  return issues;
}
"""

TITLE_JS = r"""
(slide) => {
  const marked = slide.querySelector('[data-title]');
  if (marked) return (marked.innerText || marked.textContent).replace(/\s+/g, ' ').trim();
  let best = null, size = 0;
  for (const el of slide.querySelectorAll('h1, h2, h3, [class]')) {
    const own = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
    if (el.closest('svg')) continue;
    const txt = (el.innerText || '').replace(/\s+/g, ' ').trim();
    if (!own || txt.replace(/[\d\s.,%／/：:、·•]/g, '').length < 6) continue;
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (fs > size) { size = fs; best = txt; }
  }
  return best ? '（未標 data-title，推測）' + best : '（找不到標題）';
}
"""


FILLER = ["賦能", "助力", "打造", "全方位", "一站式", "持續優化", "顯著提升", "大幅提升", "深度融合", "閉環", "抓手",
          "賽道", "極致", "無縫", "革命性", "引領", "底層邏輯", "降本增效"]
AILOOK_JS = r"""() => {
  const out = [];
  const css = [...document.styleSheets].flatMap(s => { try { return [...s.cssRules].map(r => r.cssText); } catch (e) { return []; } }).join('\n');
  if (/backdrop-filter/.test(css)) out.push('CSS 用了 backdrop-filter（毛玻璃）');
  const f = css.match(/font-family:[^;]*\b(Inter|Poppins|Montserrat|Roboto)\b/);
  if (f) out.push('CSS 用了通用字型 ' + f[1] + '（改回樣板字型）');
  return out;
}"""


def ailook(pg):
    out = pg.evaluate(AILOOK_JS)
    for i, s in enumerate(pg.query_selector_all(".slide"), 1):
        text = s.inner_text()
        hits = [w for w in FILLER if w in text]
        if hits:
            out.append(f"p{i} 空泛詞：{'、'.join(hits)}（改成具體數字或動作）")
    return out


def shoot(browser, html: Path, out_dir: Path, scale: int, check: bool):
    pg = browser.new_page(viewport={"width": 1664, "height": 1000}, device_scale_factor=scale)
    pg.goto(html.resolve().as_uri())
    pg.wait_for_load_state("networkidle")
    pg.evaluate("document.fonts.ready")
    shots, report, titles = [], {}, []
    for i, s in enumerate(pg.query_selector_all(".slide"), 1):
        name = s.get_attribute("data-name") or f"{i:02d}"
        out = out_dir / f"{html.stem}-{name}.png"
        s.screenshot(path=str(out))
        shots.append(out)
        if check:
            report[out.name] = s.evaluate(CHECK_JS)
            titles.append(f"{i}. {s.evaluate(TITLE_JS)}")
    if check:
        titles = (titles, ailook(pg))
    pg.close()
    return shots, report, titles


def contact_sheet(images, dest: Path, stem="", cols=3, w=520):
    from PIL import Image, ImageDraw, ImageFont
    thumbs = []
    for p in images:
        im = Image.open(p).convert("RGB")
        thumbs.append(im.resize((w, round(im.height * w / im.width))))
    h = max(t.height for t in thumbs)
    pad, lab = 24, 34
    rows = -(-len(thumbs) // cols)
    sheet = Image.new("RGB", (pad + cols * (w + pad), pad + rows * (h + lab + pad)), "#F3F1EC")
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("msjhbd.ttc", 20)
    except OSError:
        font = ImageFont.load_default()
    for i, (t, p) in enumerate(zip(thumbs, images)):
        x, y = pad + (i % cols) * (w + pad), pad + (i // cols) * (h + lab + pad)
        name = p.stem[len(stem) + 1:] if stem and p.stem.startswith(stem + "-") else p.stem
        while name and d.textlength(f"{i + 1}  {name}", font=font) > w:
            name = name[:-1]
        d.text((x, y), f"{i + 1}  {name}", fill="#17171A", font=font)
        sheet.paste(t, (x, y + lab))
        d.rectangle([x - 1, y + lab - 1, x + w, y + lab + t.height], outline="#CFCAC0")
    sheet.save(dest)


def to_pptx(images, dest: Path):
    from pptx import Presentation
    from pptx.util import Emu
    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)  # 16:9
    for img in images:
        sl = prs.slides.add_slide(prs.slide_layouts[6])
        sl.shapes.add_picture(str(img), 0, 0, prs.slide_width, prs.slide_height)
    prs.save(dest)


def to_pdf(images, dest: Path):
    from PIL import Image
    pages = [Image.open(p).convert("RGB") for p in images]
    pages[0].save(dest, save_all=True, append_images=pages[1:], resolution=200)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html", nargs="+", type=Path)
    ap.add_argument("--out", type=Path)
    ap.add_argument("--pptx", action="store_true")
    ap.add_argument("--pptx-image", action="store_true")
    ap.add_argument("--pdf", action="store_true")
    a = ap.parse_args()

    report, exports, titles, sheets, looks = {}, [], {}, [], {}
    with sync_playwright() as p:
        try:
            b = p.chromium.launch(channel="msedge")
        except Exception:
            b = p.chromium.launch()
        for html in a.html:
            out_dir = a.out or html.parent / "previews"
            out_dir.mkdir(parents=True, exist_ok=True)
            shots, r, (t, look) = shoot(b, html, out_dir, 1, True)
            report.update(r)
            titles[html.name] = t
            looks[html.name] = look
            sheet = out_dir / f"_sheet-{html.stem}.png"
            if shots:
                contact_sheet(shots, sheet, html.stem); sheets.append(str(sheet))
            if a.pptx:
                sys.path.insert(0, str(Path(__file__).parent))
                from editable_pptx import export
                with tempfile.TemporaryDirectory() as tmp:
                    export(b, html, html.with_suffix(".pptx"), Path(tmp)); exports.append(str(html.with_suffix(".pptx")))
            if a.pptx_image or a.pdf:
                with tempfile.TemporaryDirectory() as tmp:
                    hi, _, _ = shoot(b, html, Path(tmp), 2, False)
                    if a.pptx_image:
                        dest = html.with_name(html.stem + "-image.pptx")
                        to_pptx(hi, dest); exports.append(str(dest))
                    if a.pdf:
                        to_pdf(hi, html.with_suffix(".pdf")); exports.append(str(html.with_suffix(".pdf")))
        b.close()

    sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps({"slides": report, "titles": titles, "ailook": looks, "sheet": sheets, "exports": exports},
                     ensure_ascii=False, indent=1))
    sys.exit(1 if any(report.values()) else 0)


if __name__ == "__main__":
    main()
