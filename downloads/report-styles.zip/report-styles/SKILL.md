---
name: report-styles
description: Use when producing a work report or slides (HTML, PNG, PPTX, PDF) - monthly/weekly/sprint report, KPI summary, project status, incident or problem review, proposal or decision request, architecture or training deck - or when the user mentions work-report, report_styles, 工作報告, 月報, 週報, 專案進度, 問題檢討, 事故報告, 提案, 顧問式, 麥肯錫, McKinsey, 金字塔原則, SCQA, 行動標題, 故事線, storyline, 報告風格, 套用風格, 財經報紙風, 瑞士網格風, 便當盒儀表板, 深色戰情室, 活潑貼紙風, 企業藍白, 稽核報告, 筆記本, 速查表, cheat sheet, 講義, 手繪, 白板, sketch, 架構圖, 資料流程圖, 分工圖, or says a report looks too plain (太陽春) or its message is unclear.
---

# 工作報告（report-styles，又稱 work-report）

一份報告分兩層：
- **裏（內容）**：用顧問式敘事決定每頁講什麼、標題怎麼寫、順序怎麼排。
- **外（視覺）**：8 種已驗證的企業報告風格，每種都有可直接複製的 HTML 樣板（1600×900 投影片），附建置與檢查腳本，可輸出 PNG、PPTX、PDF。

`<skill>` = 本檔所在目錄，例如 `%USERPROFILE%\.agents\skills\report-styles`。

| 檔案 | 管什麼 |
|---|---|
| `storylines.md` | 判斷報告類型；5 種報告的頁序；頁面角色 → 各風格版面 |
| `narrative.md` | 故事線格式、行動標題、執行摘要（SCQA）、下一步、敘事檢查 |
| `charts.md` | 依訊息選圖；各風格有哪些圖表元件 |
| `style-index.md` | 風格索引卡（正式度、文字密度、適合／不適合、投影或列印）＋自動推薦規則 |
| `styles.md` | 8 種風格的 token、元件、版面、禁忌；「別像 AI 做的」禁用清單 |
| `review.md` | 交付前審稿：四面向燈號、結論規則、審稿員提示 |
| `scripts/` | `build.py` 建置＋版面檢查＋標題串讀＋AI 感提示＋縮圖總覽；`editable_pptx.py` 可編輯 PPTX（`build.py --pptx` 會呼叫）；`pptx_preview.py` 用 PowerPoint 把 PPTX 轉成圖檢查；`check_numbers.py` 數字核對；`leftover.py` 樣板殘留 |

## 選風格

| # | 風格 | 樣板 | 最適合的場景 |
|---|---|---|---|
| ① | 財經報紙風 | `templates/01-editorial.html` | 給主管看的正式月報或季報，標題直接寫結論 |
| ② | 瑞士網格風 | `templates/02-swiss.html` | 高層或對外正式簡報，數字少但份量重 |
| ③ | 便當盒儀表板 | `templates/03-bento.html` | 每月固定格式的團隊月報、KPI 總覽 |
| ④ | 深色戰情室 | `templates/04-command-center.html` | 系統監控、上線或異常回顧，需要燈號警示 |
| ⑤ | 活潑貼紙風 | `templates/05-playful-sticker.html` | 團隊內部分享、慶功、週會 |
| ⑥ | 企業藍白 | `templates/06-corporate-blue.html` | 公司正式報告：稽核／合規結果、系統工具介紹、教育訓練、提案。有 3 種頁型：儀表板、流程案例、架構說明 |
| ⑦ | 筆記本速查表 | `templates/07-notebook-cheatsheet.html` | 一頁看完的重點整理：月報速查、教育訓練講義、操作摘要、待辦與下一步 |
| ⑧ | 手繪架構圖 | `templates/08-sketch-architecture.html` | 資料流程／系統架構說明、誰負責什麼的分工圖、白板討論整理。顏色和框線都有固定意義，每頁必附圖例 |

- 使用者已經指名風格：直接用。
- 使用者沒有指定：
  1. 讀 `<skill>/style-index.md`，照「推薦規則」算分，挑出 1 個推薦＋2 個備選。
  2. 在回覆中嵌入總覽圖 `![風格總覽](<skill>/assets/overview.png)`，路徑要展開成絕對路徑。
  3. 用 ask_user 讓使用者選擇。推薦的放第一個並標註「(推薦)」，問題裡用一句話說推薦原因。
- 單頁預覽圖在 `assets/previews/`：①–⑤ 是 `NN-*-cover.png`、`NN-*-data.png`；⑥ 是 `06-corporate-blue-dashboard／process／structure.png`；⑦ 是 `07-notebook-cheatsheet-cheatsheet／next-steps.png`；⑧ 是 `08-sketch-architecture-data-flow／who-did-what.png`。

## 產出步驟

**只換風格的情況**：使用者只要求換風格或套用風格，而且內容已定稿（例如已有核准版簡報）時，不改內容的頁序和文字，跳過步驟 1–2，從步驟 3 開始。交付時可另附「標題改寫建議」清單給使用者自行決定。

1. **判斷類型與讀者**：讀 `<skill>/storylines.md`，依資料判斷報告類型（A 月報／B 專案進度／C 問題檢討／D 提案／E 架構說明），寫下讀者和讀者讀完要做的事。
2. **寫故事線並確認**：讀 `<skill>/narrative.md`，照第 1 節的格式寫出故事線：每頁角色、行動標題、證據、圖。第 2 頁是執行摘要（SCQA；頁數受限時依合併規則併入封面），最後一頁要有下一步。用 ask_user 請使用者確認；使用者已說「直接做」或「不用問」時，跳過確認，交付時附上故事線。
3. **選風格**：見上方「選風格」。推薦照 `style-index.md` 的推薦規則（已包含 `storylines.md` 該類型的推薦風格）。
4. **讀規格**：打開 `<skill>/styles.md`，閱讀所選風格的段落，包括 token、元件 class、延伸頁型和禁忌；再讀 `<skill>/charts.md`，依每頁的訊息選圖表元件。
5. **整理真實資料**：
   - 列出要呈現的數字和結論。每個數字都要能對回來源檔。
   - 缺值標成「未填」，不能補猜。
   - 頁序照故事線。使用者指定頁數時，依 `storylines.md` 的「合併規則」縮減。⑥⑦⑧ 沒有封面頁型，第一頁直接用該風格的第一種頁型。
6. **複製樣板**：把樣板複製到使用者的輸出目錄，例如 `<project>\report\index.html`。**不要修改 `<skill>/templates/` 裡的原檔。**
   - 保留 `<style>`、結尾的兩段 `<script>`（簡報模式、`id="edit-mode"` 編輯模式）和 `.hint`。`<head>` 裡只改 `<title>`，換成新報告名稱。
   - 只改寫 `<section class="slide" data-name="英文短名">`。用不到的頁型整段刪掉。
   - 樣板內的數據只是範例（8 份都是「好日子生活館客服組 10 月客訴月報」，全部虛構），所有文字和數字都要換成新資料。
7. **做頁面**：
   - 每頁用哪個版面，查 `storylines.md` 的「頁面角色 → 各風格版面」。同一版面可以重複使用。
   - 每頁的大標題寫故事線裡的**行動標題**。樣板原本的主題式標題（例如「誰做了多少？」）一律改寫。
   - 在放行動標題的那個元素加上 `data-title`，例如 `<h2 class="ttl" data-title>`。`build.py` 會依此列出標題串讀；沒加時它只能用最大字推測。
   - 只用該風格既有的 CSS 和元件。新加的東西要遵守 `styles.md`「別像 AI 做的」。
   - 需要新元件時，CSS 加在同一個 `<style>`，並使用同一組 token；需要新圖示時，在頁面 SVG 的 `<defs>` 加 `<symbol>`，線條風格比照現有圖示。
   - 圖表的寬度和高度依真實比例計算。
   - 樣板以外的文案（例如註腳）也必須來自資料，不能沿用樣板裡的句子。
8. **建置與檢查**（必做）：
   ```powershell
   python <skill>\scripts\build.py <輸出>\index.html            # PNG 輸出到 <輸出>\previews\
   python <skill>\scripts\build.py <輸出>\index.html --pptx --pdf   # 需要 PPTX / PDF 時加上
   python <skill>\scripts\pptx_preview.py <輸出>\index.pptx          # 有 PPTX 時必做：用 PowerPoint 轉圖檢查
   ```
   - `--pptx`：**可編輯**版 `index.pptx`。背景、圖表、圖示是一張圖，文字是真的文字框，可在 PowerPoint 直接改字。
   - `--pptx-image`：圖片版 `index-image.pptx`，每頁一張圖，外觀 100% 一樣但不能改字。使用者只要「看」不要「改」時用。
   - `pptx_preview.py` 輸出 `previews\index-pptx-NN.png` 和 `_sheet-index-pptx.png`。把它和 HTML 的 `_sheet-index.png` 對看：文字位置差 1–3px 正常；字跑掉、換行不同、字型不對就要修。exit 2 代表這台電腦沒有 PowerPoint，告訴使用者沒能檢查。
   - JSON 有四部分：
     - `slides`：每頁的版面問題（超出投影片、格子內文字被裁掉、文字擠進格子內距、文字互相重疊、亂碼），每條附超出多少 px 和建議改法。全部是 `[]`、exit code 為 0 才算通過。
     - `titles`：標題串讀，用來做 `narrative.md` 第 8 節的檢查。
     - `ailook`：「像 AI 做的」提示（空泛詞、毛玻璃、通用字型）。不影響 exit code，但每條都要改掉或說明理由。
     - `sheet`：縮圖總覽圖。先 view 這張看整體節奏，再逐張 view PNG。箭頭交叉、箭頭消失、大片空白只能靠看圖。
   - **數字核對**：`python <skill>\scripts\check_numbers.py <輸出>\index.html <來源檔...>`。來源要是文字檔（md／csv／json），Excel 先存成 csv。逐條看 `?`：改正數字，或在旁邊寫出算式（例：「23 / 33 小時」）讓它變成 `≈`。標「小數字」的 ✔ 也要看：推算出來的（例如 2+1+1=4）一樣要寫算式。圖表刻度、頁碼這類非資料數字，在元素上加 `data-nocheck`。
   - **樣板殘留**：`python <skill>\scripts\leftover.py <輸出>\index.html <skill>\templates\<樣板>.html`。exit 1 只代表「有清單要看」，不是失敗。逐條看列出的文字：新資料真的這樣說就保留，否則改寫。另外 grep「常見錯誤」第一列的範例詞（新資料剛好有同名詞時除外）。
   - **審稿**：照 `<skill>/review.md`，交給另一個 agent 打四面向燈號並給結論。結論是「重做」或「小修」就照它的 3 件事修改，再建置、核對、審稿。最多審 3 次，細節見 `review.md`「收到審稿之後」。
9. **交付**：回報以下內容：
   - 故事線表格（至少有「# ／ 行動標題」兩欄）
   - HTML 路徑，並說明「按 P 進入簡報模式，方向鍵翻頁，Esc 離開；按 E 可直接點文字修改，Ctrl+S 存檔（第一次會問存哪裡，選原檔覆蓋即可）。改數字不會自動改圖表長度，圖表要改請找我」
   - PNG 預覽資料夾，並在回覆中嵌入縮圖總覽圖 `_sheet-*.png`
   - 審稿結論和四面向燈號（例：「小修｜故事 🟢 標題 🟡 證據 🟢 畫面 🟢」），以及沒修完的項目
   - PPTX／PDF 路徑（如有）。PPTX 要說明「文字可以直接在 PowerPoint 改；圖表長度、圖示是圖片，改數字不會改圖」，並附 `_sheet-index-pptx.png`

## 資料與版面規則

- **推算數字**：可以從來源數字算出百分比、比例或差距，但圖說要寫出依據，例如「105 / 150 點」。不能加入來源沒有的事實。
- **樣板需要的資料不存在**：例如沒有單件 Effort，就換成另一個真實指標，或直接刪掉那一格，不要硬填。
- **多種未完成狀態**：「進行中」和「未指派」要用不同樣式（見 styles.md 各風格的狀態變體），圖說也要分別寫明。
- **排名高亮**：在排名或長條圖裡，`.hot`、claret、紅色、⑧ 的 `.mk` 螢光筆只給「依序累加、剛好達到約 70% 的前幾名」，最多 3 名。例如前 2 名已占 69.7%，就只標 2 名。⑦ 的 `.key`／`.hl` 是「一句話」裡的關鍵數字，不屬於排名高亮。
- **缺值**：圖表列用斜線區塊並寫「未填」，數值欄可以寫「—」；內文一律寫「未填」。
- **避免大片空白**：長條或清單少於 6 列時，不要讓列平均撐滿整個高格子。改用固定列高並靠上排，或縮小那一格，把空間讓給另一個重點。每格內容至少要占格子高度的一半。

## 注意

- **可編輯 PPTX（`--pptx`）的限制**，交付時要讓使用者知道：
  - 能改：所有一般文字（標題、數字、說明、表格文字）。
  - 不能改：圖表長度、色塊、圖示、SVG 裡的文字（例如 ⑧ 箭頭上的字），這些都在背景圖裡。改了數字，長條不會跟著變。
  - 每一行是一個段落：改字後太長不會自動換到下一行，要自己按 Enter。
  - 看的電腦要有同樣字型（Noto Sans TC 等），否則 PowerPoint 會換字型，位置會跑掉。
  - 某段文字想留在圖裡、不要變文字框：在 HTML 元素上加 `data-noedit`。
  - 需要外觀完全一致：用 `--pptx-image`。PDF 一律是每頁一張圖。
- **編輯模式**：程式在 `scripts/edit-mode.snippet.html`，已內建在 8 份樣板。舊報告沒有時，把整段貼到 `</body>` 前，並把 `.hint` 改成「按 P 進入簡報模式（方向鍵翻頁，Esc 離開）｜按 E 編輯文字（Ctrl+S 存檔）」。只能改文字；圖表長度、版面要改 HTML。
- 渲染使用 Playwright 搭配 Edge（`channel="msedge"`），找不到 Edge 時改用內建 Chromium。

## 常見錯誤

| 錯誤 | 正確做法 |
|---|---|
| 留下範例文字。8 份樣板都要 grep：`好日子`、`Good Days`、`客訴`、`C-0`、`C-1`、`86.7`、`69.7`、`33 小時`、`林佳穎`、`陳冠宇`、`黃詩涵`、`張家豪`、`李雅婷`、`許志明`、`王美玲`、`待主管決定` | 全部換成新資料：跑 `scripts/leftover.py` 逐條確認，並 grep 這些字要 0 筆（新資料剛好有同名詞時除外） |
| 圖表長度隨手寫 | 依 `值 ÷ 最大值` 計算 |
| 混用兩種風格的 class | 一份報告只用一種風格 |
| 文字太多，硬塞進格子 | 拆成兩頁，或縮短文字；不要把字級縮到 15px 以下（只有頁尾 `.src`、`.pg` 可以 14px） |
| 只看 JSON 就交付 | 一定要實際看縮圖總覽和每張 PNG |
| 交付 PPTX 前沒用 `pptx_preview.py` 看過 | 轉圖後和 HTML 縮圖對看；沒有 PowerPoint 就明說沒檢查 |
| 加了紫藍漸層、emoji 當項目符號、整排一樣的圓角卡片、「賦能／打造／全方位」 | 照 `styles.md`「別像 AI 做的」改；`ailook` 要清空或逐條說明 |
| 沒算分就隨口推薦風格 | 照 `style-index.md` 推薦規則算，並在 ask_user 說一句原因 |
| `check_numbers.py` 有 `?` 就把數字刪掉，或忽略不看 | 對回來源改正；推算數字在旁邊寫算式 |
| 自己審自己，寫「整體不錯」就交付 | 照 `review.md` 交給另一個 agent，四面向都要有燈號，結論照規則判定 |
| 直接修改 `templates/` | 先複製到輸出目錄再改 |
| 標題寫主題或問句（「誰做了多少？」「本月概況」） | 改成行動標題：一句含數字或判斷的結論（見 `narrative.md` 第 2 節） |
| 沒有執行摘要，第 2 頁就進細節 | 第 2 頁放 SCQA 摘要，支撐重點對應後面各頁 |
| 下一步只有口號，沒有負責人或期限 | 每項寫動作＋負責人＋期限；資料沒有就寫「待主管指定」「待定」，不編造 |
| 沒先寫故事線就開始做 HTML | 先寫故事線並確認（或交付時附上），再做頁面 |
| 標題說「2 人」，圖上卻標了 3 人 | 圖上強調的對象和行動標題一致；樣板原本的 `.hot` 要依新標題重設 |
