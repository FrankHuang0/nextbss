/* 雙人偶旁白：小貓問、機器人答。資料由 embed_duo.py 放在 window.DUO_DATA / DUO_IMG / DUO_CFG */
(() => {
  'use strict';
  const C = Object.assign({ slide: '.slide', active: 'active', next: '', home: 'tr', bar: 'bl', key: 'p' }, window.DUO_CFG || {});
  const PAGES = (window.DUO_DATA || {}).pages || {}, IMG = window.DUO_IMG || {};
  const NAME = { cat: '小貓', robot: '機器人' }, FW = 100, GAP = 10, IDLE = .72, RATES = [1, 1.25, 1.5];
  const norm = s => (s || '').replace(/\s+/g, '');
  const bare = s => norm(s).replace(/[，。、！？：；「」『』（）,.!?:;()]/g, '');
  const CARDS = Object.entries(C.cards || {}).map(([k, v]) => ({ k, v, n: bare(k) }));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const store = (k, v) => { try { if (v === undefined) return localStorage.getItem('duo.' + k); localStorage.setItem('duo.' + k, v); } catch (e) { return null; } };

  // ---------- 畫面元件 ----------
  const root = document.createElement('div'); root.id = 'duo';
  const fig = w => `<div class="duo-m ${w}"><div class="duo-say"></div><div class="duo-fig"><div class="duo-body"><img alt="${NAME[w]}" src="${IMG[w] || ''}"></div><div class="duo-shd"></div></div></div>`;
  root.innerHTML = fig('cat') + fig('robot')
    + '<div id="duoHL"></div><div id="duoCap"><div class="in"><span class="who"></span><span class="tx"></span></div></div>'
    + '<div id="duoKey"><div class="in"><span class="lb">一句話重點</span><span class="tx"></span></div></div>'
    + '<div id="duoIdm"><div class="in"><span class="lb">成語小卡</span><b class="k"></b><span class="tx"></span></div></div>'
    + `<div id="duoBar" class="${C.bar}"><button id="duoPlay" type="button">▶ 聽報告</button><button id="duoSpd" type="button" title="語速">1x</button>`
    + '<label><input type="checkbox" id="duoAuto">自動連播</label><label><input type="checkbox" id="duoSub">字幕</label>'
    + '<label><input type="checkbox" id="duoShow">人偶</label><span class="pg" id="duoPg"></span></div>';
  document.body.appendChild(root);
  const $ = id => document.getElementById(id);
  const hl = $('duoHL'), cap = $('duoCap'), keyc = $('duoKey'), idm = $('duoIdm'), btn = $('duoPlay'), spd = $('duoSpd'), cAuto = $('duoAuto'), cSub = $('duoSub'), cShow = $('duoShow'), pg = $('duoPg');

  const M = {};
  ['cat', 'robot'].forEach(w => {
    const el = root.querySelector('.duo-m.' + w);
    M[w] = { w, el, body: el.querySelector('.duo-body'), shd: el.querySelector('.duo-shd'), say: el.querySelector('.duo-say'),
      x: null, y: null, vx: 0, vy: 0, phase: 0, face: w === 'cat' ? 1 : -1, nat: w === 'cat' ? -1 : 1,   // 貓的圖原本面向左
      tilt: 0, tiltTo: 0, tiltEnd: 0, hop: -1, next: 0, ok: false, k: IDLE };
  });
  let rate = +store('rate'); if (!RATES.includes(rate)) rate = 1;
  const setRate = r => { rate = r; spd.textContent = r + 'x'; au.defaultPlaybackRate = au.playbackRate = r; };

  cAuto.checked = store('auto') === '1';
  cSub.checked = store('sub') !== '0';
  cShow.checked = store('show') !== '0';
  const syncOpt = () => { root.classList.toggle('duo-nosub', !cSub.checked); root.classList.toggle('duo-off', !cShow.checked); };
  syncOpt();
  cAuto.onchange = () => { store('auto', cAuto.checked ? '1' : '0'); cAuto.blur(); };
  cSub.onchange = () => { store('sub', cSub.checked ? '1' : '0'); syncOpt(); cSub.blur(); };
  cShow.onchange = () => { store('show', cShow.checked ? '1' : '0'); syncOpt(); cShow.blur(); };
  btn.onclick = () => { btn.blur(); NR.on ? stop() : start(); };   // start() 無參數＝手動開始
  spd.onclick = () => { setRate(RATES[(RATES.indexOf(rate) + 1) % RATES.length]); store('rate', rate); spd.blur(); };
  document.addEventListener('keydown', e => {
    const t = e.target;
    if (e.ctrlKey || e.altKey || e.metaKey || (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)))) return;
    if (e.key.toLowerCase() === C.key) { e.preventDefault(); NR.on ? stop() : start(); }
  });

  // ---------- 找目前頁面 ----------
  let SL = [], cur = -1, Z = null, S = 1;
  function scanSlides(){ const a = [...document.querySelectorAll(C.slide)]; SL = a.filter(e => !a.some(o => o !== e && o.contains(e))); }
  function curIdx(){
    if (!SL.length || !SL[0].isConnected) scanSlides();
    const i = SL.findIndex(e => e.classList.contains(C.active));
    if (i >= 0) return i;
    let best = -1, bd = 1e9;                                      // 沒有 active class：取最靠近畫面中央、看得到的那頁
    SL.forEach((e, k) => { const r = e.getBoundingClientRect(); if (!r.width || !r.height || r.bottom < 0 || r.top > innerHeight) return;
      const d = Math.abs((r.top + r.bottom) / 2 - innerHeight / 2); if (d < bd) { bd = d; best = k; } });
    return best;
  }
  function frame(){                                               // 投影片比畫面高（長頁面）時，只取看得到的那一段
    const r = SL[cur] && SL[cur].getBoundingClientRect();
    if (r && r.width) { const t = Math.max(r.top, 0), b = Math.min(r.bottom, innerHeight); Z = { left: r.left, right: r.right, width: r.width, top: t, bottom: b, height: b - t }; }
    else Z = { left: 0, top: 0, right: innerWidth, bottom: innerHeight, width: innerWidth, height: innerHeight };
    S = Math.max(.45, Math.min(1.6, Z.width / 1600));
  }
  // 長頁面：講到的重點在畫面外就捲過去（只用在有 active class 的簡報，避免和使用者捲動打架）
  function tall(){ const sl = SL[cur]; if (!sl || !sl.classList.contains(C.active)) return false; const r = sl.getBoundingClientRect(); return r.top < -2 || r.bottom > innerHeight + 2; }
  function reveal(el){
    if (!el || !tall()) return;
    const r = el.getBoundingClientRect(), top = 90, bot = innerHeight - 170;
    if (r.top >= top && Math.min(r.bottom, r.top + innerHeight * .45) <= bot) return;
    el.style.scrollMarginTop = top + 'px';
    el.scrollIntoView({ behavior: calm ? 'auto' : 'smooth', block: r.height > innerHeight * .45 ? 'start' : 'center' });
  }
  addEventListener('scroll', () => { NR.tg = null; }, { passive: true, capture: true });

  // ---------- 旁白狀態 ----------
  const NR = { on: false, i: 0, segs: null, seg: null, el: null, tg: null, arr: 0, playing: false, timer: 0, pending: false, navAt: 0, hold: false, seen: new Set() };
  const au = new Audio();
  setRate(rate);
  au.onended = () => { NR.playing = false; if (NR.on) NR.timer = setTimeout(() => runSeg(NR.i + 1), 450); };

  function page(){ return PAGES[cur + 1]; }
  function upd(){
    const p = page();
    btn.disabled = !p || !p.segs.length;
    btn.textContent = NR.on ? '■ 停止' : '▶ 聽報告';
    pg.textContent = NR.on ? `${NR.i + 1} / ${NR.segs.length}` : '';
    root.classList.toggle('duo-on', NR.on);
  }
  function start(fromAuto){
    const p = page();
    if (!p || !p.segs.length) {                                   // 沒有對話的頁：連播中就停 4 秒再翻頁
      NR.hold = fromAuto === true && cAuto.checked && cur < SL.length - 1;
      if (NR.hold) NR.timer = setTimeout(() => { NR.pending = true; NR.navAt = performance.now(); nextPage(); }, 4000);
      return;
    }
    clearTimeout(NR.timer); NR.pending = false; NR.hold = false; NR.seen = new Set(); keyc.style.display = 'none';
    Object.assign(NR, { on: true, segs: p.segs, el: null, tg: null, arr: 0 });
    runSeg(0);
  }
  function stop(){
    clearTimeout(NR.timer); NR.pending = false; NR.hold = false;
    if (NR.on) { NR.on = false; au.pause(); NR.playing = false; }
    clearSeg(); upd();
  }
  function clearSeg(){ NR.seg = null; NR.el = null; cap.style.display = 'none'; hl.style.display = 'none'; idm.style.display = 'none'; M.cat.say.classList.remove('on'); M.robot.say.classList.remove('on'); }
  function idiom(s){                                              // 講到成語就跳出小卡，同一頁同一詞只出現一次
    const t = bare(s.t); let best = null;
    for (const c of CARDS) { const at = t.indexOf(c.n); if (c.n && at >= 0 && !NR.seen.has(c.k) && (!best || at < best.at)) best = { c, at }; }
    if (!best) { idm.style.display = 'none'; return; }
    NR.seen.add(best.c.k);
    idm.querySelector('.k').textContent = best.c.k; idm.querySelector('.tx').textContent = best.c.v;
    idm.style.display = 'none'; void idm.offsetWidth; idm.style.display = 'block';
  }
  function runSeg(i){
    if (!NR.on) return;
    const s = NR.segs[i];
    if (!s) { endPage(); return; }
    const el = s.at.q ? findEl(s.at.q) : null;
    if (el !== NR.el || s.at.p || s.at.home) NR.tg = null;
    NR.i = i; NR.seg = s; NR.el = el;
    reveal(el);
    const sp = M[s.who], ot = M[s.who === 'cat' ? 'robot' : 'cat'];
    ot.say.classList.remove('on'); sp.say.classList.remove('on'); sp.say.innerHTML = s.tip;
    cap.querySelector('.who').className = 'who ' + s.who; cap.querySelector('.who').textContent = NAME[s.who];
    cap.querySelector('.tx').textContent = s.t; cap.style.display = 'block';
    idiom(s);
    au.src = 'data:audio/mpeg;base64,' + s.a; NR.playing = false; au.defaultPlaybackRate = au.playbackRate = rate;
    au.play().then(() => { NR.playing = true; }).catch(e => {
      if (e.name === 'NotAllowedError') stop(); else NR.timer = setTimeout(() => runSeg(i + 1), 300);
    });
    upd();
  }
  function endPage(){
    const p = page(), auto = cAuto.checked && cur < SL.length - 1;
    NR.on = false; NR.playing = false; NR.hold = auto; clearSeg(); upd();
    if (p && p.key) { keyc.querySelector('.tx').textContent = p.key; keyc.style.display = 'block'; }
    if (auto) NR.timer = setTimeout(() => { keyc.style.display = 'none'; NR.pending = true; NR.navAt = performance.now(); nextPage(); }, p && p.key ? 3500 : 1000);
  }
  function nextPage(){
    if (C.next) { try { new Function(C.next)(); return; } catch (e) { console.warn('[duo] next 指令失敗', e); } }
    const e = new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', bubbles: true, cancelable: true });
    Object.defineProperty(e, 'keyCode', { get: () => 39 }); Object.defineProperty(e, 'which', { get: () => 39 });
    document.body.dispatchEvent(e);
  }
  function onPage(){
    keyc.style.display = 'none'; clearTimeout(NR.timer);
    if (tall() && SL[cur].getBoundingClientRect().top < 0) SL[cur].scrollIntoView({ block: 'start' });   // 換頁後從頁首開始
    if (NR.pending) { NR.pending = false; NR.on = false; clearSeg(); NR.timer = setTimeout(() => start(true), 700); upd(); }
    else stop();
  }

  // ---------- 錨點與站位 ----------
  function findEl(q){
    const n = norm(q), sl = SL[cur]; if (!sl) return null;
    const els = [...sl.querySelectorAll('*')].filter(e => e.getClientRects().length && norm(e.textContent).includes(n));
    els.sort((a, b) => a.textContent.length - b.textContent.length);
    if (!els[0]) console.warn('[duo] 第', cur + 1, '頁找不到錨點文字：', q);
    return els[0] || null;
  }
  function boxOf(el){                                             // 重點的實際範圍：有底色/框線就用整塊，否則只包住文字
    if (el instanceof SVGElement) return el.getBoundingClientRect();
    let h = el;
    while (h.parentElement && h.parentElement !== SL[cur] && getComputedStyle(h).display.startsWith('inline')) h = h.parentElement;
    const cs = getComputedStyle(h), bg = cs.backgroundColor;
    if ((bg && bg !== 'transparent' && !/,\s*0\)$/.test(bg)) || parseFloat(cs.borderTopWidth) > 0 || parseFloat(cs.borderLeftWidth) > 0 || /^(TD|TH|IMG)$/.test(h.tagName)) return h.getBoundingClientRect();
    const rg = document.createRange(); rg.selectNodeContents(h);
    const rs = [...rg.getClientRects()].filter(q => q.width && q.height);
    if (!rs.length) return h.getBoundingClientRect();
    const l = Math.min(...rs.map(q => q.left)), t = Math.min(...rs.map(q => q.top)), r = Math.max(...rs.map(q => q.right)), b = Math.max(...rs.map(q => q.bottom));
    return { left: l, top: t, right: r, bottom: b, width: r - l, height: b - t };
  }
  function hlRect(el){
    const r = boxOf(el);
    return r.width * r.height > Z.width * Z.height * .55 ? null : r;
  }
  function obstacles(){
    const out = [], rg = document.createRange(), sl = SL[cur], w = document.createTreeWalker(sl, NodeFilter.SHOW_TEXT);
    for (let n; (n = w.nextNode());) {
      if (!n.nodeValue.trim()) continue;
      if (n.parentElement.closest('svg')) { const r = n.parentElement.getBoundingClientRect(); if (r.width) out.push(r); continue; }
      rg.selectNodeContents(n); for (const r of rg.getClientRects()) if (r.width) out.push(r);
    }
    sl.querySelectorAll('img,canvas,video').forEach(e => { const r = e.getBoundingClientRect(); if (r.width) out.push(r); });
    return out;
  }
  function bubbleLeft(w, mx, bw){                                 // 泡泡往外側展開，且不超出投影片
    const c = mx + FW * S / 2, L = w === 'cat' ? c - bw + 34 * S : c - 34 * S;
    return Math.max(Z.left + 4 * S, Math.min(Z.right - 4 * S - bw, L));
  }
  function bottomPad(){ return (cSub.checked ? 100 : 14) * S; }
  let barR = null;
  function homeOf(w){                                             // 待命：縮小站在角落，並讓開播放列
    const fw = FW * S * IDLE, g = GAP * S, left = C.home[1] === 'l', top = C.home[0] !== 'b';
    const rx = left ? Z.left + 14 * S + fw + g : Z.right - 14 * S - fw;
    let y = top ? Z.top + 12 * S : Z.bottom - fw - bottomPad();
    const b = barR;
    if (b && b.width && b.right > rx - fw - g && b.left < rx + fw && b.bottom > y && b.top < y + fw) y = top ? b.bottom + 6 * S : b.top - fw - 6 * S;
    return w === 'robot' ? { x: rx, y } : { x: rx - fw - g, y };
  }
  // 兩隻人偶並排（貓左、機器人右）站在重點旁邊，挑「蓋到最少文字、又離重點近」的位置
  function pairTarget(now){
    const at = NR.seg.at, fw = FW * S, g = GAP * S, W = 2 * fw + g;
    const x0 = Z.left + 6 * S, x1 = Z.right - W - 6 * S, y0 = Z.top + 120 * S, y1 = Math.max(y0, Z.bottom - fw - bottomPad());
    const cl = (x, y) => [Math.max(x0, Math.min(x1, x)), Math.max(y0, Math.min(y1, y))];
    if (at.home) return null;
    if (at.p) { const [x, y] = cl(Z.left + at.p[0] / 100 * Z.width - W / 2, Z.top + at.p[1] / 100 * Z.height - fw / 2); return { x, y }; }
    if (!NR.el) return null;
    const c = NR.tg;
    if (c && c.S === S && (c.done || now - c.t < 900)) return c;
    const r = boxOf(NR.el), obs = obstacles(), sp = NR.seg.who;
    const bw = M[sp].say.offsetWidth * S, bh = M[sp].say.offsetHeight * S;
    const ov = (x, y, w, h) => { let s = 0; for (const o of obs) { const dx = Math.min(x + w, o.right) - Math.max(x, o.left), dy = Math.min(y + h, o.bottom) - Math.max(y, o.top); if (dx > 0 && dy > 0) s += dx * dy; } return s; };
    const rg = document.createRange(); rg.selectNodeContents(NR.el); const tr = [...rg.getClientRects()].filter(q => q.width).pop();
    const cy = r.top + Math.min(r.height / 2, 50 * S) - fw / 2, xs = [r.left, r.left + r.width / 2 - W / 2, r.right - W];
    const cand = [[r.right + g, cy], [r.left - g - W, cy], [r.right + g, r.top - fw / 2], [r.left - g - W, r.top - fw / 2]];
    xs.forEach(x => cand.push([x, r.top - fw - g], [x, r.bottom + g]));
    if (tr) cand.push([tr.right + g, tr.top + tr.height / 2 - fw / 2]);
    for (let a = NR.el.parentElement, k = 0; a && a !== SL[cur] && k < 4; a = a.parentElement, k++) {   // 也試試站在整個表格/區塊旁邊
      const ar = a.getBoundingClientRect();
      if (ar.right > r.right + 1) cand.push([ar.right + g, cy]);
      if (ar.left < r.left - 1) cand.push([ar.left - g - W, cy]);
    }
    const hit = (x, y, w, h) => Math.max(0, Math.min(x + w, r.right) - Math.max(x, r.left)) * Math.max(0, Math.min(y + h, r.bottom) - Math.max(y, r.top));
    let best = null;
    for (const p of cand) {
      const [x, y] = cl(p[0], p[1]), sx = sp === 'cat' ? x : x + fw + g;
      const bx = bubbleLeft(sp, sx, bw), by = y - bh - 12 * S, fx = x + fw * .15, fy = y + fw * .1, fW = W - fw * .3, fH = fw * .85;
      const dx = Math.max(r.left - (x + W), 0, x - r.right), dy = Math.max(r.top - (y + fw), 0, y - r.bottom);
      const sc = 2 * ov(fx, fy, fW, fH) + 1.4 * ov(bx, by, bw, bh) + 4 * hit(fx, fy, fW, fH) + 2 * hit(bx, by, bw, bh) + Math.hypot(dx, dy) * fw * .25;
      if (!best || sc < best.sc) best = { x, y, sc };
    }
    NR.tg = { x: best.x, y: best.y, S, t: c && c.S === S ? c.t : now, done: !!c && c.S === S };
    return NR.tg;
  }

  // ---------- 走路 ----------
  // 各走各的路：貓先出發，機器人晚一點才跟上；遠距離時兩隻各自走一條往不同邊彎的弧線
  const LAG = 520;
  function plan(m, t, now){
    const want = m.nt || m.tg;
    if (want && Math.hypot(t.x - want.x, t.y - want.y) < 2 * S) return;
    if (Math.hypot(t.x - m.x, t.y - m.y) < 60 * S) { m.tg = t; m.nt = null; m.wp = null; return; }   // 小幅修正直接調整
    if (!m.nt) m.go = now + (m.w === 'robot' ? LAG : 0);
    m.nt = t;
  }
  function depart(m){
    m.tg = m.nt; m.nt = null; m.wp = null;
    const dx = m.tg.x - m.x, dy = m.tg.y - m.y, d = Math.hypot(dx, dy);
    if (d < 150 * S || calm) return;
    const bend = d * (m.w === 'robot' ? -.22 : .1), fw = FW * S;
    m.wp = { x: Math.max(0, Math.min(innerWidth - fw, m.x + dx / 2 - dy / d * bend)),
             y: Math.max(0, Math.min(innerHeight - fw, m.y + dy / 2 + dx / d * bend)) };
  }
  function steer(m, t, vmax, dt, pass){
    const dx = t.x - m.x, dy = t.y - m.y, d = Math.hypot(dx, dy), slow = 120 * S;
    const want = d < slow && !pass ? vmax * d / slow : vmax;
    let ax = (d > .5 ? dx / d * want : 0) - m.vx, ay = (d > .5 ? dy / d * want : 0) - m.vy;
    const a = Math.hypot(ax, ay), acc = 600 * S * dt;
    if (a > acc) { ax *= acc / a; ay *= acc / a; }
    m.vx += ax; m.vy += ay; m.x += m.vx * dt; m.y += m.vy * dt;
    return d;
  }
  function idle(m, other, now){                                    // 待命時各自有小動作
    const r = Math.random();
    if (r < .35) { m.tiltTo = Math.random() < .5 ? -7 : 7; m.tiltEnd = now + 900; }
    else if (r < .7) m.face = other.x > m.x ? 1 : -1;               // 看向對方
    else if (r < .85) m.face = -m.face;                             // 左右張望
    else m.hop = now;
    m.next = now + rnd(2600, 5600);
  }

  let last = 0, lastScan = 0, hlR = null;
  function tick(now){
    requestAnimationFrame(tick);
    const dt = Math.min(.05, last ? (now - last) / 1000 : .016); last = now;
    if (now - lastScan > 150) {
      lastScan = now; const i = curIdx();
      if (i !== cur) { const first = cur < 0; cur = i; if (!first) onPage(); upd(); }
      else if (NR.pending && now - NR.navAt > 2500) { NR.pending = false; console.warn('[duo] 換頁沒有反應，請用 --next 指定換頁指令'); }
    }
    frame();
    barR = document.getElementById('duoBar').getBoundingClientRect();
    const fw = FW * S, g = GAP * S, on = NR.on && NR.seg, hold = !on && NR.hold && M.cat.tg;
    root.classList.toggle('duo-act', !!(on || hold));
    const pt = on ? pairTarget(now) : null;
    const T = pt ? { cat: { x: pt.x, y: pt.y }, robot: { x: pt.x + fw + g, y: pt.y } }
      : hold ? { cat: M.cat.tg, robot: M.robot.tg } : { cat: homeOf('cat'), robot: homeOf('robot') };
    const vmax = (on ? 320 : 200) * S;
    let both = true;
    for (const w of ['cat', 'robot']) {
      const m = M[w], o = M[w === 'cat' ? 'robot' : 'cat'];
      if (m.x === null) { m.x = T[w].x; m.y = T[w].y; m.tg = T[w]; m.next = now + rnd(2000, 4000); }
      plan(m, T[w], now);
      if (m.nt && now >= m.go) depart(m);
      if (m.wp && Math.hypot(m.wp.x - m.x, m.wp.y - m.y) < 40 * S) m.wp = null;
      steer(m, m.wp || m.tg, vmax * (w === 'robot' ? 1.12 : 1), dt, !!m.wp);
      const sp = Math.hypot(m.vx, m.vy), d = Math.hypot(m.tg.x - m.x, m.tg.y - m.y);
      m.ok = !m.nt && !m.wp && d < 5 * S && sp < 15 * S; both = both && m.ok;
      const moving = sp > 18 * S, amp = Math.min(1, sp / (180 * S));
      if (moving) { m.phase += sp * dt / (38 * S) * Math.PI; if (Math.abs(m.vx) > 14 * S) m.face = m.vx < 0 ? -1 : 1; }
      else if (m.nt) m.face = o.x > m.x ? 1 : -1;                  // 還沒出發的那隻先轉頭看對方
      else if (on) {
        m.face = w === 'cat' ? 1 : -1;                              // 對話時面對面
        if (NR.seg.who !== w && now > m.next) { m.tiltTo = Math.random() < .5 ? -5 : 5; m.tiltEnd = now + 500; m.next = now + rnd(1800, 3200); }   // 聽的人點點頭
      } else if (now > m.next) idle(m, o, now);
      if (now > m.tiltEnd) m.tiltTo = 0;
      m.tilt += (m.tiltTo - m.tilt) * Math.min(1, dt * 8);
      const step = Math.abs(Math.sin(m.phase));
      let lift = moving ? step * 10 * amp : 0, rot = (moving ? Math.sin(m.phase) * 7 * amp : 0) + m.tilt, sq = moving ? 1 - .06 * (1 - step) * amp : 1;
      if (m.hop >= 0) { const k = (now - m.hop) / 380; if (k >= 1) m.hop = -1; else lift += Math.sin(k * Math.PI) * 20; }
      if (on && NR.playing && NR.seg.who === w && !moving) sq *= 1 + .035 * Math.sin(now / 75);   // 說話時嘴巴動的感覺
      if (calm) { lift = 0; rot = 0; sq = 1; }
      m.k += ((on || hold ? 1 : IDLE) - m.k) * Math.min(1, dt * 4);
      m.el.style.transform = `translate(${m.x}px,${m.y}px) scale(${S * m.k})`;
      m.body.style.transform = `translateY(${-lift}px) rotate(${rot}deg) scale(${m.face * m.nat}, ${sq})`;
      m.shd.style.transform = `scale(${1 - lift / 45})`; m.shd.style.opacity = 1 - lift / 55;
    }
    NR.arr = on && both ? NR.arr || now : 0;

    if (on) {
      // 泡泡：兩隻都站好 0.2 秒後才出現
      const m = M[NR.seg.who], show = NR.arr && now - NR.arr > 200;
      if (show) {
        const bw = m.say.offsetWidth * S, L = bubbleLeft(m.w, m.x, bw);
        m.say.style.left = (L - m.x) / S + 'px';
        m.say.style.setProperty('--tx', Math.max(16, Math.min(m.say.offsetWidth - 16, (m.x + fw / 2 - L) / S)) + 'px');
      }
      m.say.classList.toggle('on', !!show);
      // ① 打亮
      const r = NR.el ? hlRect(NR.el) : null;
      if (r) {
        const p = 8 * S, t = { x: r.left - p, y: r.top - p, w: r.width + 2 * p, h: r.height + 2 * p }, k = hl.style.display === 'none' || !hlR ? 1 : Math.min(1, dt * 10);
        hlR = hlR && k < 1 ? { x: hlR.x + (t.x - hlR.x) * k, y: hlR.y + (t.y - hlR.y) * k, w: hlR.w + (t.w - hlR.w) * k, h: hlR.h + (t.h - hlR.h) * k } : t;
        Object.assign(hl.style, { display: 'block', transform: `translate(${hlR.x}px,${hlR.y}px)`, width: hlR.w + 'px', height: hlR.h + 'px' });
      } else { hl.style.display = 'none'; hlR = null; }
    }
    // ② 字幕、③ 重點卡 跟著投影片縮放，並避開播放列
    const fs = Math.max(15, 24 * S), bar = barR;
    const low = bar.height && bar.top > innerHeight / 2 ? innerHeight - bar.top + 8 : 0, cb = Math.max(innerHeight - Z.bottom + 16 * S, low);
    Object.assign(cap.style, { left: Z.left + Z.width * .08 + 'px', width: Z.width * .84 + 'px', bottom: cb + 'px', fontSize: fs + 'px' });
    Object.assign(idm.style, { left: Z.left + Z.width * .08 + 'px', bottom: cb + (cap.offsetHeight || 0) + 10 * S + 'px', fontSize: Math.max(14, 20 * S) + 'px' });
    Object.assign(keyc.style, { left: Z.left + Z.width * .1 + 'px', width: Z.width * .8 + 'px', bottom: Math.max(innerHeight - Z.bottom + 40 * S, low) + 'px', fontSize: Math.max(18, 30 * S) + 'px' });
  }

  scanSlides(); cur = curIdx(); frame(); upd();
  requestAnimationFrame(tick);
  window.DUO = { start, stop, audio: au, get page(){ return cur + 1; } };
})();
