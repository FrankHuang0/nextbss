/* 雙人偶旁白：小貓問、機器人答。資料由 embed_duo.py 放在 window.DUO_DATA / DUO_CFG；人偶是下面的 inline SVG */
(() => {
  'use strict';
  const C = Object.assign({ slide: '.slide', active: 'active', next: '', home: 'tr', bar: 'bl', key: 'p', scroll: false }, window.DUO_CFG || {});
  const PAGES = (window.DUO_DATA || {}).pages || {};
  const NAME = { cat: '小貓', robot: '機器人' }, FW = 120, FH = 150, GAP = 6, IDLE = .72, RATES = [1, 1.25, 1.5];
  // 人偶（柔和立體款）：viewBox 120×150，部位拆成可動的 <g>：.bre 呼吸、.tail 尾巴、.al/.ar 左右手、.head 轉頭、.hd 表情、.pp 眼珠、.lid 眼皮、.mo 嘴、.halo 天線燈
  const SVG = {
    cat: '<svg class="duo-svg" viewBox="0 0 120 150" role="img" aria-label="小貓"><defs>'
      + '<radialGradient id="duocF" cx=".38" cy=".3" r=".85"><stop offset="0" stop-color="#FFE3B8"/><stop offset=".5" stop-color="#FFB45E"/><stop offset="1" stop-color="#DC7429"/></radialGradient>'
      + '<radialGradient id="duocB" cy=".3" r=".7"><stop offset="0" stop-color="#FFFBF4"/><stop offset="1" stop-color="#FFD7AC"/></radialGradient>'
      + '<radialGradient id="duocK" cx=".4" cy=".3" r=".8"><stop offset="0" stop-color="#6b4a36"/><stop offset="1" stop-color="#1b110b"/></radialGradient>'
      + '<linearGradient id="duocT" x2="0" y2="1"><stop offset="0" stop-color="#FFB45E"/><stop offset="1" stop-color="#E07B2E"/></linearGradient>'
      + '<clipPath id="duocE1"><ellipse cx="46" cy="63" rx="7" ry="8.5"/></clipPath><clipPath id="duocE2"><ellipse cx="74" cy="63" rx="7" ry="8.5"/></clipPath></defs>'
      + '<g class="bre" stroke-linecap="round">'
      + '<g class="tail" fill="none"><path d="M80 132c22 2 32-14 24-36" stroke="url(#duocT)" stroke-width="9"/><path d="M104 96c1 3 1 6 0 9" stroke="#FFE3B8" stroke-width="3" opacity=".7"/></g>'
      + '<g class="body"><ellipse cx="60" cy="118" rx="30" ry="27" fill="url(#duocF)"/><ellipse cx="60" cy="124" rx="17" ry="16" fill="url(#duocB)"/><ellipse cx="46" cy="143" rx="9" ry="5" fill="#FFC27A"/><ellipse cx="74" cy="143" rx="9" ry="5" fill="#FFC27A"/></g>'
      + '<g class="al"><path d="M39 105l-2 19" stroke="#F6A24D" stroke-width="9"/></g><g class="ar"><path d="M81 105l2 19" stroke="#F6A24D" stroke-width="9"/></g>'
      + '<g class="head"><g class="hd">'
      + '<path d="M28 50l5-40 25 22zM92 50l-5-40-25 22z" fill="url(#duocT)" stroke="#F0A050" stroke-width="3" stroke-linejoin="round"/><path d="M35 40l2-18 13 10zM85 40l-2-18-13 10z" fill="#FFA3B5"/>'
      + '<ellipse cx="60" cy="62" rx="36" ry="32" fill="url(#duocF)"/><ellipse cx="44" cy="41" rx="8" ry="4" fill="#fff" opacity=".3" transform="rotate(-25 44 41)"/>'
      + '<path d="M54 33v7M60 31v9M66 33v7" stroke="#D9732C" stroke-width="3" opacity=".55"/>'
      + '<g fill="#FF7E98" opacity=".35"><ellipse cx="34" cy="76" rx="7" ry="4.5"/><ellipse cx="86" cy="76" rx="7" ry="4.5"/></g>'
      + '<g class="eye"><g class="eo"><g class="pp"><ellipse cx="46" cy="63" rx="7" ry="8.5" fill="url(#duocK)"/><circle cx="48.5" cy="59.5" r="2.6" fill="#fff"/><circle cx="44" cy="67" r="1.1" fill="#fff" opacity=".7"/><g clip-path="url(#duocE1)"><rect class="lid" x="38" y="54" width="16" height="18" fill="#FBA552"/></g></g></g><path class="eh" d="M39 65q7-9 14 0" fill="none" stroke="#3a2516" stroke-width="3"/></g>'
      + '<g class="eye"><g class="eo"><g class="pp"><ellipse cx="74" cy="63" rx="7" ry="8.5" fill="url(#duocK)"/><circle cx="76.5" cy="59.5" r="2.6" fill="#fff"/><circle cx="72" cy="67" r="1.1" fill="#fff" opacity=".7"/><g clip-path="url(#duocE2)"><rect class="lid" x="66" y="54" width="16" height="18" fill="#FBA552"/></g></g></g><path class="eh" d="M67 65q7-9 14 0" fill="none" stroke="#3a2516" stroke-width="3"/></g>'
      + '<g stroke="#8a4a1e" stroke-width="2.5" fill="none"><path class="brow b1" d="M39 48q7-4 13 0"/><path class="brow b2" d="M68 48q7-4 13 0"/></g>'
      + '<g class="mo"><ellipse cx="60" cy="82" rx="6" ry="6" fill="#6e2424"/><ellipse cx="60" cy="85.5" rx="3.6" ry="2.2" fill="#FF8FA3"/></g>'
      + '<path d="M56.5 70.5h7l-3.5 3.5z" fill="#F47A8C"/><path d="M54 76q3 4 6 0q3 4 6 0" fill="none" stroke="#7a3f1d" stroke-width="2"/>'
      + '<path d="M25 71l-12-2M25 77l-12 2M95 71l12-2M95 77l12 2" stroke="#fff" stroke-width="1.6" opacity=".9"/>'
      + '</g></g></g></svg>',
    robot: '<svg class="duo-svg" viewBox="0 0 120 150" role="img" aria-label="機器人"><defs>'
      + '<radialGradient id="duorW" cx=".35" cy=".25" r=".9"><stop offset="0" stop-color="#fff"/><stop offset=".55" stop-color="#EEE9F7"/><stop offset="1" stop-color="#B5A7D8"/></radialGradient>'
      + '<linearGradient id="duorV" x2="0" y2="1"><stop offset="0" stop-color="#433A78"/><stop offset="1" stop-color="#1A1534"/></linearGradient>'
      + '<linearGradient id="duorC" x2="0" y2="1"><stop offset="0" stop-color="#8AF6FF"/><stop offset="1" stop-color="#2E8CFF"/></linearGradient>'
      + '<linearGradient id="duorP" x2="0" y2="1"><stop offset="0" stop-color="#FF77AB"/><stop offset="1" stop-color="#CF1A5E"/></linearGradient>'
      + '<linearGradient id="duorG" x2="0" y2="1"><stop offset="0" stop-color="#D9D2EC"/><stop offset="1" stop-color="#9C8DC6"/></linearGradient>'
      + '<clipPath id="duorR1"><rect x="44" y="44" width="9" height="15" rx="4.5"/></clipPath><clipPath id="duorR2"><rect x="67" y="44" width="9" height="15" rx="4.5"/></clipPath></defs>'
      + '<g class="bre" stroke-linecap="round">'
      + '<rect x="44" y="127" width="12" height="18" rx="5" fill="url(#duorG)"/><rect x="64" y="127" width="12" height="18" rx="5" fill="url(#duorG)"/>'
      + '<g class="body"><rect x="34" y="84" width="52" height="50" rx="16" fill="url(#duorW)"/><rect x="46" y="97" width="28" height="18" rx="7" fill="url(#duorV)"/><circle cx="55" cy="106" r="3.2" fill="url(#duorC)"/><circle cx="65" cy="106" r="3.2" fill="url(#duorP)"/></g>'
      + '<g class="al"><path d="M34 99l-2 21" stroke="url(#duorG)" stroke-width="7"/><circle cx="32" cy="123" r="6" fill="url(#duorP)"/></g>'
      + '<g class="ar"><path d="M86 99l2 21" stroke="url(#duorG)" stroke-width="7"/><circle cx="88" cy="123" r="6" fill="url(#duorP)"/></g>'
      + '<rect x="53" y="76" width="14" height="10" fill="url(#duorG)"/>'
      + '<g class="head"><g class="hd">'
      + '<g class="ant"><path d="M60 30V18" stroke="#9C8DC6" stroke-width="3"/><circle class="halo" cx="60" cy="12" r="11" fill="#FF77AB"/><circle class="bulb" cx="60" cy="12" r="5.5" fill="url(#duorP)"/><circle cx="58" cy="10" r="1.6" fill="#fff" opacity=".8"/></g>'
      + '<rect x="19" y="45" width="11" height="22" rx="5" fill="url(#duorP)"/><rect x="90" y="45" width="11" height="22" rx="5" fill="url(#duorP)"/>'
      + '<rect x="26" y="28" width="68" height="52" rx="18" fill="url(#duorW)"/><rect x="44" y="24" width="32" height="7" rx="3.5" fill="#FFC23A"/>'
      + '<rect x="34" y="36" width="52" height="38" rx="13" fill="url(#duorV)"/><path d="M40 41q10-3 20-3" stroke="#fff" stroke-width="2" opacity=".25" fill="none"/>'
      + '<g class="eye"><g class="eo"><g class="pp"><rect x="44" y="44" width="9" height="15" rx="4.5" fill="url(#duorC)"/><g clip-path="url(#duorR1)"><rect class="lid" x="43" y="43" width="11" height="17" fill="#2f2858"/></g></g></g><path class="eh" d="M43 55q5-8 10 0" fill="none" stroke="#8AF6FF" stroke-width="3"/></g>'
      + '<g class="eye"><g class="eo"><g class="pp"><rect x="67" y="44" width="9" height="15" rx="4.5" fill="url(#duorC)"/><g clip-path="url(#duorR2)"><rect class="lid" x="66" y="43" width="11" height="17" fill="#2f2858"/></g></g></g><path class="eh" d="M66 55q5-8 10 0" fill="none" stroke="#8AF6FF" stroke-width="3"/></g>'
      + '<g stroke="#8AF6FF" stroke-width="2.5"><path class="brow b1" d="M43 40h10"/><path class="brow b2" d="M67 40h10"/></g>'
      + '<rect class="mc" x="54" y="64" width="12" height="3" rx="1.5" fill="#8AF6FF"/><rect class="mo" x="52" y="63" width="16" height="9" rx="4" fill="url(#duorC)"/>'
      + '</g></g></g></svg>'
  };
  const SHOULDER = { cat: { l: [39, 105], r: [81, 105] }, robot: { l: [34, 99], r: [86, 99] } };   // 舉手指向時的肩膀位置（viewBox 座標）
  const norm = s => (s || '').replace(/\s+/g, '');
  const bare = s => norm(s).replace(/[，。、！？：；「」『』（）,.!?:;()]/g, '');
  const CARDS = Object.entries(C.cards || {}).map(([k, v]) => ({ k, v, n: bare(k) }));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const store = (k, v) => { try { if (v === undefined) return localStorage.getItem('duo.' + k); localStorage.setItem('duo.' + k, v); } catch (e) { return null; } };

  // ---------- 畫面元件 ----------
  const root = document.createElement('div'); root.id = 'duo';
  const fig = w => `<div class="duo-m ${w}"><div class="duo-say"></div><div class="duo-fig"><div class="duo-body">${SVG[w]}</div><div class="duo-shd"></div></div></div>`;
  root.innerHTML = fig('cat') + fig('robot')
    + '<div id="duoHL"></div><div id="duoCap"><div class="in"><span class="who"></span><span class="tx"></span></div></div>'
    + '<div id="duoKey"><div class="in"><span class="lb">一句話重點</span><span class="tx"></span></div></div>'
    + '<div id="duoIdm"><div class="in"><span class="lb">成語小卡</span><b class="k"></b><span class="tx"></span></div></div>'
    + `<div id="duoBar" class="${C.bar}"><button id="duoPlay" type="button">▶ 聽報告</button><button id="duoSpd" type="button" title="語速">1x</button>`
    + '<label><input type="checkbox" id="duoAuto">自動連播</label><label><input type="checkbox" id="duoSub">字幕</label>'
    + '<label><input type="checkbox" id="duoShow">人偶</label><span class="pg" id="duoPg"></span></div>';
  document.body.appendChild(root);
  const $ = id => document.getElementById(id);
  const hl = $('duoHL'), cap = $('duoCap'), keyc = $('duoKey'), idm = $('duoIdm'), btn = $('duoPlay'), spd = $('duoSpd'), cAuto = $('duoAuto'), cSub = $('duoSub'), cShow = $('duoShow'), pg = $('duoPg');

  const M = {};
  ['cat', 'robot'].forEach(w => {
    const el = root.querySelector('.duo-m.' + w), sv = el.querySelector('svg'), q = s => sv.querySelector(s);
    sv.classList.add(w === 'cat' ? 'cat' : 'bot');
    M[w] = { w, el, body: el.querySelector('.duo-body'), shd: el.querySelector('.duo-shd'), say: el.querySelector('.duo-say'),
      svg: sv, head: q('.head'), pp: [...sv.querySelectorAll('.pp')], mo: q('.mo'), mc: q('.mc'), halo: q('.halo'), bulb: q('.bulb'), arm: { l: q('.al'), r: q('.ar') },
      x: null, y: null, vx: 0, vy: 0, phase: 0, face: w === 'cat' ? 1 : -1,   // face：眼睛和頭朝向（1 右、-1 左），不翻轉整張圖
      look: 0, turn: 0, turnTo: 0, nodT: -1, lv: 0, expr: '', exprEnd: 0, blinkAt: 0, blinkEnd: 0, ang: { l: 0, r: 0 }, angTo: { l: 0, r: 0 }, talk: false,
      tilt: 0, tiltTo: 0, tiltEnd: 0, hop: -1, next: 0, ok: false, k: IDLE };
  });
  let rate = +store('rate'); if (!RATES.includes(rate)) rate = 1;
  const setRate = r => { rate = r; spd.textContent = r + 'x'; au.defaultPlaybackRate = au.playbackRate = r; };

  cAuto.checked = store('auto') === '1';
  cSub.checked = store('sub') !== '0';
  cShow.checked = store('show') !== '0';
  const syncOpt = () => { root.classList.toggle('duo-nosub', !cSub.checked); root.classList.toggle('duo-off', !cShow.checked); };
  syncOpt();
  cAuto.onchange = () => { store('auto', cAuto.checked ? '1' : '0'); cAuto.blur(); };
  cSub.onchange = () => { store('sub', cSub.checked ? '1' : '0'); syncOpt(); cSub.blur(); };
  cShow.onchange = () => { store('show', cShow.checked ? '1' : '0'); syncOpt(); cShow.blur(); };
  btn.onclick = () => { btn.blur(); NR.on ? stop() : start(); };   // start() 無參數＝手動開始
  spd.onclick = () => { setRate(RATES[(RATES.indexOf(rate) + 1) % RATES.length]); store('rate', rate); spd.blur(); };
  document.addEventListener('keydown', e => {
    const t = e.target;
    if (e.ctrlKey || e.altKey || e.metaKey || (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)))) return;
    if (e.key.toLowerCase() === C.key) { e.preventDefault(); NR.on ? stop() : start(); }
  });

  // ---------- 找目前頁面 ----------
  // 捲動模式（C.scroll）：一路往下捲的長網頁，每個段落當一頁；播放中鎖定該段，不因捲動而換頁
  let SL = [], cur = -1, Z = null, S = 1, lock = -1, autoAt = 0;
  function scanSlides(){ const a = [...document.querySelectorAll(C.slide)]; SL = a.filter(e => !a.some(o => o !== e && o.contains(e))); }
  function curIdx(){
    if (!SL.length || !SL[0].isConnected) scanSlides();
    if (C.scroll && lock >= 0 && SL[lock]) return lock;
    const i = SL.findIndex(e => e.classList.contains(C.active));
    if (i >= 0) return i;
    let best = -1, bd = 1e9;                                      // 沒有 active class：取最靠近畫面中央、看得到的那頁
    SL.forEach((e, k) => { const r = e.getBoundingClientRect(); if (!r.width || !r.height || r.bottom < 0 || r.top > innerHeight) return;
      const d = Math.abs((r.top + r.bottom) / 2 - innerHeight / 2); if (d < bd) { bd = d; best = k; } });
    if (best < 0 && C.scroll && SL[0] && SL[0].getBoundingClientRect().top >= innerHeight) best = 0;   // 捲動模式在頁首（大圖佔滿畫面）：當作第一段，▶ 才能按
    return best;
  }
  function frame(){                                               // 投影片比畫面高（長頁面）時，只取看得到的那一段
    const r = SL[cur] && SL[cur].getBoundingClientRect();
    if (r && r.width && Math.min(r.bottom, innerHeight) - Math.max(r.top, 0) > 40) { const t = Math.max(r.top, 0), b = Math.min(r.bottom, innerHeight); Z = { left: r.left, right: r.right, width: r.width, top: t, bottom: b, height: b - t }; }
    else if (r && r.width) Z = { left: r.left, right: r.right, width: r.width, top: 0, bottom: innerHeight, height: innerHeight };
    else Z = { left: 0, top: 0, right: innerWidth, bottom: innerHeight, width: innerWidth, height: innerHeight };
    S = Math.max(.55, Math.min(1.4, Z.width / 1200));
  }
  // 長頁面：講到的重點在畫面外就捲過去（只用在有 active class 的簡報，避免和使用者捲動打架）
  function tall(){ const sl = SL[cur]; if (!sl || !(C.scroll || sl.classList.contains(C.active))) return false; const r = sl.getBoundingClientRect(); return r.top < -2 || r.bottom > innerHeight + 2; }
  function reveal(el){
    if (!el || !tall()) return;
    const r = el.getBoundingClientRect(), top = 90, bot = innerHeight - 170;
    if (r.top >= top && Math.min(r.bottom, r.top + innerHeight * .45) <= bot) return;
    autoAt = performance.now();
    el.style.scrollMarginTop = top + 'px';
    el.scrollIntoView({ behavior: calm ? 'auto' : 'smooth', block: r.height > innerHeight * .45 ? 'start' : 'center' });
  }
  addEventListener('scroll', () => {
    NR.tg = null;
    if (C.scroll && !NR.on && !NR.hold && !NR.pending && performance.now() - autoAt > 1200) lock = -1;   // 使用者自己捲動：解除鎖定
  }, { passive: true, capture: true });

  // ---------- 旁白狀態 ----------
  const NR = { on: false, i: 0, segs: null, seg: null, el: null, tg: null, arr: 0, playing: false, timer: 0, pending: false, navAt: 0, hold: false, seen: new Set() };
  const au = new Audio();
  setRate(rate);
  // 段與段的停頓：照 duo.json 每段的 g（毫秒，gen_duo_audio.py 依「問句快接、長回答多停」算好）；舊資料沒有 g 就用 450
  au.onended = () => { NR.playing = false; const s = NR.seg, g = s && s.g != null ? s.g : 450; if (NR.on) NR.timer = setTimeout(() => runSeg(NR.i + 1), g / (au.playbackRate || 1)); };

  // ---------- 對嘴：Web Audio 讀音量 ----------
  // AudioContext 只在使用者按 ▶／P 時建立或 resume（瀏覽器規定）；createMediaElementSource 同一個元素只能接一次。
  // 建不起來、file:// 開啟、或讀到的一直是 0（例如靜音）時，改用模擬的說話節奏，不影響播放。
  const AU = { ctx: null, an: null, buf: null, linked: false, fake: location.protocol === 'file:', zero: 0, segFake: false, fk: { t: 0, v: 0 } };
  function initAudio(){
    if (AU.fake) return;
    try {
      if (!AU.ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (!AC) { AU.fake = true; return; } AU.ctx = new AC(); }
      const link = () => {
        if (AU.linked || AU.ctx.state !== 'running') return;
        AU.linked = true;                                        // 一定要 running 才接，否則聲音會被吃掉
        const src = AU.ctx.createMediaElementSource(au);
        AU.an = AU.ctx.createAnalyser(); AU.an.fftSize = 1024; AU.buf = new Float32Array(AU.an.fftSize);
        src.connect(AU.an); AU.an.connect(AU.ctx.destination);
      };
      if (AU.ctx.state === 'running') link();
      else AU.ctx.resume().then(link).catch(() => {});
    } catch (e) { AU.fake = !AU.linked; }
  }
  function level(now, dt){                                       // 目前音量 → 0～1 的嘴巴張開度
    if (au.paused || !NR.playing) return 0;
    if (AU.an && !AU.segFake) {
      if (AU.ctx.state === 'suspended') AU.ctx.resume().catch(() => {});
      AU.an.getFloatTimeDomainData(AU.buf);
      let s = 0; for (let i = 0; i < AU.buf.length; i++) s += AU.buf[i] * AU.buf[i];
      const rms = Math.sqrt(s / AU.buf.length);
      if (rms < 1e-6) { AU.zero += dt; if (AU.zero > 1.2) AU.segFake = true; } else AU.zero = 0;   // 一直讀到 0：這段改用模擬
      const t = Math.max(0, Math.min(1, (20 * Math.log10(rms + 1e-7) + 40) / 28));
      return t < .12 ? 0 : t;
    }
    const f = AU.fk;
    if (now > f.t) { f.t = now + 80 + Math.random() * 120; f.v = Math.random() < .2 ? 0 : .3 + Math.random() * .7; }
    return f.v;
  }

  // ---------- 表情、眨眼、點頭 ----------
  function setExpr(m, e){
    if (m.expr === e) return;
    m.svg.classList.remove('e-happy', 'e-confused', 'e-surprised'); if (e) m.svg.classList.add('e-' + e); m.expr = e;
  }
  // 依台詞自動挑表情（不用改稿格式）：小貓問句＝疑惑；有「哇」「真的」或「！」結尾＝先驚訝再開心；機器人預設開心
  function exprOf(s){
    const t = (s.t || '').trim(), q = /[？?]$/.test(t), wow = /哇|真的/.test(t) || /[！!]$/.test(t);
    if (s.who === 'robot') return { a: wow ? 'surprised' : 'happy', b: '' };
    return { a: wow ? 'surprised' : q ? 'confused' : '', b: q ? 'confused' : wow ? 'happy' : '' };
  }

  function page(){ return PAGES[cur + 1]; }
  function upd(){
    const p = page();
    btn.disabled = !p || !p.segs.length;
    btn.textContent = NR.on ? '■ 停止' : '▶ 聽報告';
    pg.textContent = NR.on ? `${NR.i + 1} / ${NR.segs.length}` : '';
    root.classList.toggle('duo-on', NR.on);
  }
  function start(fromAuto){
    if (fromAuto !== true) initAudio();                           // 使用者按 ▶／P：這時才能建立 AudioContext
    const p = page();
    if (!p || !p.segs.length) {                                   // 沒有對話的頁：連播中就停 4 秒再翻頁
      NR.hold = fromAuto === true && cAuto.checked && cur < SL.length - 1;
      if (NR.hold) NR.timer = setTimeout(() => { NR.pending = true; NR.navAt = performance.now(); nextPage(); }, 4000);
      return;
    }
    clearTimeout(NR.timer); NR.pending = false; NR.hold = false; NR.seen = new Set(); keyc.style.display = 'none';
    if (C.scroll) {                                               // 捲動模式：這段開頭落在畫面下半部時，先捲上來，人偶才不會被字幕擋住
      lock = cur;
      const r = SL[cur].getBoundingClientRect();
      if (r.top > innerHeight * 0.45) { autoAt = performance.now(); SL[cur].style.scrollMarginTop = '80px'; SL[cur].scrollIntoView({ behavior: 'auto', block: 'start' }); }
    }
    Object.assign(NR, { on: true, segs: p.segs, el: null, tg: null, arr: 0 });
    runSeg(0);
  }
  function stop(){
    clearTimeout(NR.timer); NR.pending = false; NR.hold = false; lock = -1;
    if (NR.on) { NR.on = false; au.pause(); NR.playing = false; }
    clearSeg(); upd();
  }
  function clearSeg(){ NR.seg = null; NR.el = null; cap.style.display = 'none'; hl.style.display = 'none'; idm.style.display = 'none'; root.classList.remove('duo-aside'); M.cat.say.classList.remove('on'); M.robot.say.classList.remove('on'); }
  function idiom(s){                                              // 講到成語就跳出小卡，同一頁同一詞只出現一次
    const t = bare(s.t); let best = null;
    for (const c of CARDS) { const at = t.indexOf(c.n); if (c.n && at >= 0 && !NR.seen.has(c.k) && (!best || at < best.at)) best = { c, at }; }
    if (!best) { idm.style.display = 'none'; return; }
    NR.seen.add(best.c.k);
    idm.querySelector('.k').textContent = best.c.k; idm.querySelector('.tx').textContent = best.c.v;
    idm.style.display = 'none'; void idm.offsetWidth; idm.style.display = 'block';
  }
  function runSeg(i){
    if (!NR.on) return;
    const s = NR.segs[i];
    if (!s) { endPage(); return; }
    const el = s.at.q ? findEl(s.at.q) : null;
    if (el !== NR.el || s.at.p || s.at.home) NR.tg = null;
    NR.i = i; NR.seg = s; NR.el = el; NR.arr = 0;
    reveal(el);
    const sp = M[s.who], ot = M[s.who === 'cat' ? 'robot' : 'cat'];
    ot.say.classList.remove('on'); sp.say.classList.remove('on'); sp.say.innerHTML = s.tip;
    // 幕後解說：跳出場景，用第三人稱說明剛才的動作；開始時兩隻一起跳一下
    if (s.off && !root.classList.contains('duo-aside') && !calm) M.cat.hop = M.robot.hop = performance.now();
    root.classList.toggle('duo-aside', !!s.off);
    cap.querySelector('.who').className = 'who ' + s.who; cap.querySelector('.who').textContent = (s.off ? '🎬 ' : '') + NAME[s.who] + (s.off ? '・幕後' : '');
    cap.querySelector('.tx').textContent = s.t; cap.style.display = 'block';
    idiom(s);
    NR.ex = exprOf(s); NR.segAt = performance.now(); AU.zero = 0; AU.segFake = false;
    au.src = 'data:audio/mpeg;base64,' + s.a; NR.playing = false; au.defaultPlaybackRate = au.playbackRate = rate;
    au.play().then(() => { NR.playing = true; }).catch(e => {
      if (e.name === 'NotAllowedError') stop(); else NR.timer = setTimeout(() => runSeg(i + 1), 300);
    });
    upd();
  }
  function endPage(){
    const p = page(), auto = cAuto.checked && cur < SL.length - 1;
    NR.on = false; NR.playing = false; NR.hold = auto; clearSeg(); upd();
    if (!calm) { const e = performance.now() + 1800; M.cat.exprEnd = M.robot.exprEnd = e; setExpr(M.cat, 'happy'); setExpr(M.robot, 'happy'); }   // 講完一頁，兩隻笑一下
    autoAt = performance.now();                                   // 捲動模式：先保留鎖定，重點卡才不會被換頁收掉；使用者一捲就解除
    if (p && p.key) { keyc.querySelector('.tx').textContent = p.key; keyc.style.display = 'block'; }
    if (auto) NR.timer = setTimeout(() => { keyc.style.display = 'none'; NR.pending = true; NR.navAt = performance.now(); nextPage(); }, p && p.key ? 3500 : 1000);
  }
  function nextPage(){
    if (C.scroll) {                                               // 捲動模式：捲到下一段
      const n = SL[cur + 1]; if (!n) return;
      lock = cur + 1; autoAt = performance.now();
      n.style.scrollMarginTop = '80px';
      n.scrollIntoView({ behavior: calm ? 'auto' : 'smooth', block: 'start' });
      return;
    }
    if (C.next) { try { new Function(C.next)(); return; } catch (e) { console.warn('[duo] next 指令失敗', e); } }
    const e = new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', bubbles: true, cancelable: true });
    Object.defineProperty(e, 'keyCode', { get: () => 39 }); Object.defineProperty(e, 'which', { get: () => 39 });
    document.body.dispatchEvent(e);
  }
  function onPage(){
    keyc.style.display = 'none'; clearTimeout(NR.timer);
    if (!C.scroll && tall() && SL[cur].getBoundingClientRect().top < 0) SL[cur].scrollIntoView({ block: 'start' });   // 換頁後從頁首開始
    if (NR.pending) { NR.pending = false; NR.on = false; clearSeg(); NR.timer = setTimeout(() => start(true), 700); upd(); }
    else stop();
  }

  // ---------- 錨點與站位 ----------
  function findEl(q){
    const n = norm(q), sl = SL[cur]; if (!sl) return null;
    const els = [...sl.querySelectorAll('*')].filter(e => e.getClientRects().length && norm(e.textContent).includes(n));
    els.sort((a, b) => a.textContent.length - b.textContent.length);
    if (!els[0]) console.warn('[duo] 第', cur + 1, '頁找不到錨點文字：', q);
    return els[0] || null;
  }
  function boxOf(el){                                             // 重點的實際範圍：有底色/框線就用整塊，否則只包住文字
    if (el instanceof SVGElement) return el.getBoundingClientRect();
    let h = el;
    while (h.parentElement && h.parentElement !== SL[cur] && getComputedStyle(h).display.startsWith('inline')) h = h.parentElement;
    const cs = getComputedStyle(h), bg = cs.backgroundColor;
    if ((bg && bg !== 'transparent' && !/,\s*0\)$/.test(bg)) || parseFloat(cs.borderTopWidth) > 0 || parseFloat(cs.borderLeftWidth) > 0 || /^(TD|TH|IMG)$/.test(h.tagName)) return h.getBoundingClientRect();
    const rg = document.createRange(); rg.selectNodeContents(h);
    const rs = [...rg.getClientRects()].filter(q => q.width && q.height);
    if (!rs.length) return h.getBoundingClientRect();
    const l = Math.min(...rs.map(q => q.left)), t = Math.min(...rs.map(q => q.top)), r = Math.max(...rs.map(q => q.right)), b = Math.max(...rs.map(q => q.bottom));
    return { left: l, top: t, right: r, bottom: b, width: r - l, height: b - t };
  }
  function hlRect(el){
    const r = boxOf(el);
    return r.width * r.height > Z.width * Z.height * .55 ? null : r;
  }
  function obstacles(){                                           // 捲動模式也避開畫面上其他段落的文字，人偶才不會擋到下一段標題
    const out = [], rg = document.createRange(), sl = SL[cur], box = C.scroll ? document.body : sl, w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT);
    const vis = r => r.width && r.bottom > 0 && r.top < innerHeight;
    for (let n; (n = w.nextNode());) {
      if (!n.nodeValue.trim() || root.contains(n)) continue;
      if (n.parentElement.closest('svg')) { const r = n.parentElement.getBoundingClientRect(); if (vis(r)) out.push(r); continue; }
      rg.selectNodeContents(n); for (const r of rg.getClientRects()) if (vis(r)) out.push(r);
    }
    box.querySelectorAll('img,canvas,video').forEach(e => { const r = e.getBoundingClientRect(); if (vis(r)) out.push(r); });
    return out;
  }
  function bubbleLeft(w, mx, bw){                                 // 泡泡往外側展開，且不超出投影片
    const c = mx + FW * S / 2, L = w === 'cat' ? c - bw + 34 * S : c - 34 * S;
    return Math.max(Z.left + 4 * S, Math.min(Z.right - 4 * S - bw, L));
  }
  function bottomPad(){ return (cSub.checked ? 100 : 14) * S; }
  let barR = null;
  function homeOf(w){                                             // 待命：縮小站在角落，並讓開播放列
    const fw = FW * S * IDLE, fh = FH * S * IDLE, g = GAP * S, left = C.home[1] === 'l', top = C.home[0] !== 'b';
    const rx = left ? Z.left + 14 * S + fw + g : Z.right - 14 * S - fw;
    let y = top ? Z.top + 12 * S : Z.bottom - fh - bottomPad();
    const b = barR;
    if (b && b.width && b.right > rx - fw - g && b.left < rx + fw && b.bottom > y && b.top < y + fh) y = top ? b.bottom + 6 * S : b.top - fh - 6 * S;
    return w === 'robot' ? { x: rx, y } : { x: rx - fw - g, y };
  }
  // 兩隻人偶並排（貓左、機器人右）站在重點旁邊，挑「蓋到最少文字、又離重點近」的位置
  function pairTarget(now){
    const at = NR.seg.at, fw = FW * S, fh = FH * S, g = GAP * S, W = 2 * fw + g;
    const x0 = Z.left + 6 * S, x1 = Z.right - W - 6 * S, y0 = Z.top + 120 * S, y1 = Math.max(y0, Z.bottom - fh - bottomPad());
    const cl = (x, y) => [Math.max(x0, Math.min(x1, x)), Math.max(y0, Math.min(y1, y))];
    if (at.home) return null;
    if (at.p) { const [x, y] = cl(Z.left + at.p[0] / 100 * Z.width - W / 2, Z.top + at.p[1] / 100 * Z.height - fh / 2); return { x, y }; }
    if (!NR.el) return null;
    const c = NR.tg;
    if (c && c.S === S && (c.done || now - c.t < 900)) return c;
    const r = boxOf(NR.el), obs = obstacles(), sp = NR.seg.who;
    const bw = M[sp].say.offsetWidth * S, bh = M[sp].say.offsetHeight * S;
    const ov = (x, y, w, h) => { let s = 0; for (const o of obs) { const dx = Math.min(x + w, o.right) - Math.max(x, o.left), dy = Math.min(y + h, o.bottom) - Math.max(y, o.top); if (dx > 0 && dy > 0) s += dx * dy; } return s; };
    const rg = document.createRange(); rg.selectNodeContents(NR.el); const tr = [...rg.getClientRects()].filter(q => q.width).pop();
    const cy = r.top + Math.min(r.height / 2, 50 * S) - fh / 2, xs = [r.left, r.left + r.width / 2 - W / 2, r.right - W];
    const cand = [[r.right + g, cy], [r.left - g - W, cy], [r.right + g, r.top - fh / 2], [r.left - g - W, r.top - fh / 2]];
    xs.forEach(x => cand.push([x, r.top - fh - g], [x, r.bottom + g]));
    for (let k = 0; k <= 6; k++) cand.push([Z.left + (Z.width - W) * k / 6, r.bottom + g]);   // 重點旁邊太擠時，往同一排找空位
    if (tr) cand.push([tr.right + g, tr.top + tr.height / 2 - fh / 2]);
    for (let a = NR.el.parentElement, k = 0; a && a !== SL[cur] && k < 4; a = a.parentElement, k++) {   // 也試試站在整個表格/區塊旁邊
      const ar = a.getBoundingClientRect();
      if (ar.right > r.right + 1) cand.push([ar.right + g, cy]);
      if (ar.left < r.left - 1) cand.push([ar.left - g - W, cy]);
    }
    const hit = (x, y, w, h) => Math.max(0, Math.min(x + w, r.right) - Math.max(x, r.left)) * Math.max(0, Math.min(y + h, r.bottom) - Math.max(y, r.top));
    let best = null;
    for (const p of cand) {
      const [x, y] = cl(p[0], p[1]), sx = sp === 'cat' ? x : x + fw + g;
      const bx = bubbleLeft(sp, sx, bw), by = y - bh - 12 * S, fx = x + fw * .12, fy = y + fh * .06, fW = W - fw * .24, fH = fh * .92;
      const dx = Math.max(r.left - (x + W), 0, x - r.right), dy = Math.max(r.top - (y + fh), 0, y - r.bottom);
      const sc = 2 * ov(fx, fy, fW, fH) + 1.4 * ov(bx, by, bw, bh) + 4 * hit(fx, fy, fW, fH) + 2 * hit(bx, by, bw, bh) + Math.hypot(dx, dy) * fw * .25;
      if (!best || sc < best.sc) best = { x, y, sc };
    }
    NR.tg = { x: best.x, y: best.y, S, t: c && c.S === S ? c.t : now, done: !!c && c.S === S };
    return NR.tg;
  }

  // ---------- 走路 ----------
  // 各走各的路：貓先出發，機器人晚一點才跟上；遠距離時兩隻各自走一條往不同邊彎的弧線
  const LAG = 520;
  function plan(m, t, now){
    const want = m.nt || m.tg;
    if (want && Math.hypot(t.x - want.x, t.y - want.y) < 2 * S) return;
    if (Math.hypot(t.x - m.x, t.y - m.y) < 60 * S) { m.tg = t; m.nt = null; m.wp = null; return; }   // 小幅修正直接調整
    if (!m.nt) m.go = now + (m.w === 'robot' ? LAG : 0);
    m.nt = t;
  }
  function depart(m){
    m.tg = m.nt; m.nt = null; m.wp = null;
    const dx = m.tg.x - m.x, dy = m.tg.y - m.y, d = Math.hypot(dx, dy);
    if (d < 150 * S || calm) return;
    const bend = d * (m.w === 'robot' ? -.22 : .1), fw = FW * S;
    m.wp = { x: Math.max(0, Math.min(innerWidth - fw, m.x + dx / 2 - dy / d * bend)),
             y: Math.max(0, Math.min(innerHeight - fw, m.y + dy / 2 + dx / d * bend)) };
  }
  function steer(m, t, vmax, dt, pass){
    const dx = t.x - m.x, dy = t.y - m.y, d = Math.hypot(dx, dy), slow = 120 * S;
    const want = d < slow && !pass ? vmax * d / slow : vmax;
    let ax = (d > .5 ? dx / d * want : 0) - m.vx, ay = (d > .5 ? dy / d * want : 0) - m.vy;
    const a = Math.hypot(ax, ay), acc = 600 * S * dt;
    if (a > acc) { ax *= acc / a; ay *= acc / a; }
    m.vx += ax; m.vy += ay; m.x += m.vx * dt; m.y += m.vy * dt;
    return d;
  }
  function idle(m, other, now){                                    // 待命時各自有小動作
    const r = Math.random();
    if (r < .35) { m.tiltTo = Math.random() < .5 ? -7 : 7; m.tiltEnd = now + 900; }
    else if (r < .7) m.face = other.x > m.x ? 1 : -1;               // 看向對方
    else if (r < .85) m.face = -m.face;                             // 左右張望
    else m.hop = now;
    m.next = now + rnd(2600, 5600);
  }

  function nod(m, now){ const c = m.svg.classList; c.remove('nod'); void m.svg.getBoundingClientRect(); c.add('nod'); m.nodT = now + 750; }
  // 臉和手：眨眼、表情、對嘴、天線燈、眼珠、指向重點、說話手勢
  function parts(m, now, dt, on, moving){
    const c = m.svg.classList, me = !!(on && NR.seg.who === m.w), talk = me && NR.playing;
    c.toggle('talking', talk); c.toggle('listening', !!on && !me);
    if (m.nodT >= 0 && now > m.nodT) { c.remove('nod'); m.nodT = -1; }
    if (!m.blinkAt) m.blinkAt = now + rnd(800, 3000);
    if (now > m.blinkAt) { c.add('blink'); m.blinkEnd = now + 140; m.blinkAt = now + (Math.random() < .2 ? 320 : rnd(2500, 5500)); }
    if (m.blinkEnd && now > m.blinkEnd) { c.remove('blink'); m.blinkEnd = 0; }
    if (now > m.exprEnd) setExpr(m, me && NR.ex ? (now - NR.segAt < 1100 ? NR.ex.a : NR.ex.b) : '');
    const v = talk ? level(now, dt) : 0;
    m.lv += (v - m.lv) * Math.min(1, dt * (v > m.lv ? 28 : 14));
    const o = Math.max(m.lv, m.expr === 'surprised' ? .8 : m.expr === 'happy' ? .3 : 0);
    if (m.mo) m.mo.style.transform = `scale(${(.8 + .35 * o).toFixed(3)},${o.toFixed(3)})`;
    if (m.mc) m.mc.style.opacity = Math.max(0, 1 - o * 5).toFixed(2);
    if (m.halo) m.halo.style.opacity = talk ? (.15 + .75 * m.lv).toFixed(2) : '';
    const px = (m.face * 2) + 'px 0';
    for (const p of m.pp) p.style.translate = px;
    const to = { l: 0, r: 0 };
    if (!calm) {
      if (moving) { const s = Math.sin(m.phase) * 16; to.l = s; to.r = s; }
      else if (talk) { to.l = 6 + 14 * m.lv; to.r = -6 - 14 * m.lv; }
      if (me && NR.arr && now - NR.arr < 2600 && hlR) {           // 走到定點後先用手指向重點
        const k = S * m.k, cx = hlR.x + hlR.w / 2, cy = hlR.y + Math.min(hlR.h / 2, 30 * S);
        const sd = cx > m.x + FW * k / 2 ? 'r' : 'l', sh = SHOULDER[m.w][sd];
        const sx = m.x + sh[0] / 120 * FW * k, sy = m.y + sh[1] / 150 * FH * k;
        let a = Math.atan2(cy - sy, cx - sx) * 180 / Math.PI - 90;
        a = ((a + 180) % 360 + 360) % 360 - 180;
        to[sd] = sd === 'r' ? Math.max(-165, Math.min(-40, a)) : Math.max(40, Math.min(165, a));
      }
    }
    for (const sd of ['l', 'r']) { m.ang[sd] += (to[sd] - m.ang[sd]) * Math.min(1, dt * 9); if (m.arm[sd]) m.arm[sd].style.transform = `rotate(${m.ang[sd].toFixed(1)}deg)`; }
  }

  let last = 0, lastScan = 0, hlR = null;
  function tick(now){
    requestAnimationFrame(tick);
    const dt = Math.min(.05, last ? (now - last) / 1000 : .016); last = now;
    if (now - lastScan > 150) {
      lastScan = now; const i = curIdx();
      if (i !== cur) { const first = cur < 0; cur = i; if (!first) onPage(); upd(); }
      else if (NR.pending && now - NR.navAt > 2500) { NR.pending = false; console.warn('[duo] 換頁沒有反應，請用 --next 指定換頁指令'); }
      if (C.scroll && NR.on && now - autoAt > 1500 && SL[cur]) {   // 捲動模式：播放中使用者把這段整個捲走，就停止
        const r = SL[cur].getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight) stop();
      }
    }
    frame();
    barR = document.getElementById('duoBar').getBoundingClientRect();
    const fw = FW * S, g = GAP * S, on = NR.on && NR.seg, hold = !on && NR.hold && M.cat.tg;
    root.classList.toggle('duo-act', !!(on || hold));
    const pt = on ? pairTarget(now) : null;
    const T = pt ? { cat: { x: pt.x, y: pt.y }, robot: { x: pt.x + fw + g, y: pt.y } }
      : hold ? { cat: M.cat.tg, robot: M.robot.tg } : { cat: homeOf('cat'), robot: homeOf('robot') };
    const vmax = (on ? 420 : 220) * S;
    let both = true;
    for (const w of ['cat', 'robot']) {
      const m = M[w], o = M[w === 'cat' ? 'robot' : 'cat'];
      if (m.x === null) { m.x = T[w].x; m.y = T[w].y; m.tg = T[w]; m.next = now + rnd(2000, 4000); }
      plan(m, T[w], now);
      if (m.nt && now >= m.go) depart(m);
      if (m.wp && Math.hypot(m.wp.x - m.x, m.wp.y - m.y) < 40 * S) m.wp = null;
      steer(m, m.wp || m.tg, vmax * (w === 'robot' ? 1.12 : 1), dt, !!m.wp);
      const sp = Math.hypot(m.vx, m.vy), d = Math.hypot(m.tg.x - m.x, m.tg.y - m.y);
      m.ok = !m.nt && !m.wp && d < 5 * S && sp < 15 * S; both = both && m.ok;
      const moving = sp > 18 * S, amp = Math.min(1, sp / (180 * S));
      if (moving) { m.phase += sp * dt / (38 * S) * Math.PI; if (Math.abs(m.vx) > 14 * S) m.face = m.vx < 0 ? -1 : 1; }
      else if (m.nt) m.face = o.x > m.x ? 1 : -1;                  // 還沒出發的那隻先轉頭看對方
      else if (on) {
        m.face = w === 'cat' ? 1 : -1;                              // 對話時面對面
        if (NR.seg.who !== w && now > m.next) { if (!calm) nod(m, now); m.next = now + rnd(1600, 3000); }   // 聽的人點點頭
      } else if (now > m.next) idle(m, o, now);
      if (now > m.tiltEnd) m.tiltTo = 0;
      m.tilt += (m.tiltTo - m.tilt) * Math.min(1, dt * 8);
      const step = Math.abs(Math.sin(m.phase));
      let lift = moving ? step * 10 * amp : 0, rot = (moving ? Math.sin(m.phase) * 7 * amp : 0) + m.tilt, sq = moving ? 1 - .06 * (1 - step) * amp : 1;
      if (m.hop >= 0) { const k = (now - m.hop) / 380; if (k >= 1) m.hop = -1; else lift += Math.sin(k * Math.PI) * 20; }
      const me = on && NR.playing && NR.seg.who === w && !moving;
      if (me) { sq *= 1 + .05 * m.lv; rot += (w === 'cat' ? 3 : -3); }   // 說話時身體跟著音量動，並微微傾向對方
      if (calm) { lift = 0; rot = 0; sq = 1; }
      m.k += ((on || hold ? (me ? 1.06 : 1) : IDLE) - m.k) * Math.min(1, dt * 4);
      m.el.style.transform = `translate(${m.x}px,${m.y}px) scale(${S * m.k})`;
      m.body.style.transform = `translateY(${-lift}px) rotate(${rot}deg) scale(1, ${sq})`;
      m.shd.style.transform = `scale(${1 - lift / 45})`; m.shd.style.opacity = 1 - lift / 55;
      parts(m, now, dt, on, moving);
    }
    NR.arr = on && both ? NR.arr || now : 0;

    if (on) {
      // 泡泡：兩隻都站好 0.2 秒後才出現
      const m = M[NR.seg.who], show = NR.arr && now - NR.arr > 200;
      if (show) {
        const bw = m.say.offsetWidth * S, L = bubbleLeft(m.w, m.x, bw);
        m.say.style.left = (L - m.x) / S + 'px';
        m.say.style.setProperty('--tx', Math.max(16, Math.min(m.say.offsetWidth - 16, (m.x + fw / 2 - L) / S)) + 'px');
      }
      m.say.classList.toggle('on', !!show);
      // ① 打亮
      const r = NR.el ? hlRect(NR.el) : null;
      if (r) {
        const p = 8 * S, t = { x: r.left - p, y: r.top - p, w: r.width + 2 * p, h: r.height + 2 * p }, k = hl.style.display === 'none' || !hlR ? 1 : Math.min(1, dt * 10);
        hlR = hlR && k < 1 ? { x: hlR.x + (t.x - hlR.x) * k, y: hlR.y + (t.y - hlR.y) * k, w: hlR.w + (t.w - hlR.w) * k, h: hlR.h + (t.h - hlR.h) * k } : t;
        Object.assign(hl.style, { display: 'block', transform: `translate(${hlR.x}px,${hlR.y}px)`, width: hlR.w + 'px', height: hlR.h + 'px' });
      } else { hl.style.display = 'none'; hlR = null; }
    }
    // ② 字幕、③ 重點卡 跟著投影片縮放，並避開播放列
    const fs = Math.max(15, 24 * S), bar = barR;
    const low = bar.height && bar.top > innerHeight / 2 ? innerHeight - bar.top + 8 : 0, cb = Math.max(innerHeight - Z.bottom + 16 * S, low);
    Object.assign(cap.style, { left: Z.left + Z.width * .08 + 'px', width: Z.width * .84 + 'px', bottom: cb + 'px', fontSize: fs + 'px' });
    Object.assign(idm.style, { left: Z.left + Z.width * .08 + 'px', bottom: cb + (cap.offsetHeight || 0) + 10 * S + 'px', fontSize: Math.max(14, 20 * S) + 'px' });
    Object.assign(keyc.style, { left: Z.left + Z.width * .1 + 'px', width: Z.width * .8 + 'px', bottom: Math.max(innerHeight - Z.bottom + 40 * S, low) + 'px', fontSize: Math.max(18, 30 * S) + 'px' });
  }

  scanSlides(); cur = curIdx(); frame(); upd();
  requestAnimationFrame(tick);
  window.DUO = { start, stop, audio: au, get page(){ return cur + 1; } };
})();
