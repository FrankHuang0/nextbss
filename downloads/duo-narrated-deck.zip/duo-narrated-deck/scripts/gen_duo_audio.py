"""把「小貓問、機器人答」對話稿轉成語音，輸出 duo.json（語音以 base64 內嵌）。

用法：
  python gen_duo_audio.py 對話稿.txt --deck 簡報.html --check      # 只檢查格式、錨點、估算秒數
  python gen_duo_audio.py 對話稿.txt --deck 簡報.html -o duo.json   # 產生語音
選項：--proxy http://host:port（公司網路必填；edge-tts 不吃環境變數，要用參數傳）
     --say 唸法.txt（每行「畫面字=唸法」，只影響聲音，不影響字幕）
"""
import argparse, asyncio, base64, hashlib, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from slides_text import slide_texts, norm

VOICE = {'cat': 'zh-CN-XiaoyiNeural', 'robot': 'zh-CN-YunxiNeural'}        # 小貓＝曉伊（活潑）、機器人＝雲希（親切）
RATE = {'cat': '+4%', 'robot': '+0%'}
PITCH = {'cat': '+0Hz', 'robot': '+0Hz'}
Q_PITCH = {'cat': '+6Hz', 'robot': '+0Hz'}                                  # 問句（？結尾）語調稍微上揚
WHO = {'貓': 'cat', '小貓': 'cat', 'cat': 'cat', '機': 'robot', '機器人': 'robot', 'robot': 'robot'}
KEY_SEC, TURN_SEC, CPS = 3.5, .7, 4.5                                       # 重點卡、翻頁、每秒字數(估算)
# 段與段之間的停頓（毫秒）：問句後對方很快接話、長回答後停久一點、進出幕後多停一下
GAP_Q, GAP_LONG, GAP_MID, GAP_SCENE, LONG_LEN = 120, 350, 250, 500, 40


def is_q(t): return bool(re.search(r'[？?]\s*$', t))


def pause_ms(s, nxt):
    """這一段播完、下一段開始前要等多久；頁尾回傳 0（交給重點卡）。"""
    if nxt is None: return 0
    if bool(s.get('off')) != bool(nxt.get('off')): return GAP_SCENE
    if is_q(s['t']): return GAP_Q
    return GAP_LONG if len(re.sub(r'\s', '', s['t'])) >= LONG_LEN else GAP_MID


def pitch_of(s): return (Q_PITCH if is_q(s['t']) else PITCH)[s['who']]
AI_TONE = ['讓我們', '一起來', '深入探討', '總而言之', '值得一提', '不僅', '賦能', '助力', '打造', '旨在', '至關重要', '無縫']
BASE_SAY = [('→', '，'), ('➜', '，'), ('／', '、'), ('＋', '加'), ('≥', '至少'), ('≤', '最多'), ('~', '到'), ('～', '到')]


def parse(src):
    pages, errs = {}, []
    for blk in re.split(r'\n(?=【P\d+】)', '\n' + src.replace('\r', '')):
        m = re.match(r'【P(\d+)】(.*)', blk.strip())
        if not m: continue
        n, head = int(m.group(1)), m.group(2).strip()
        km = re.match(r'重點[:：]\s*(.+)', head)
        if not km: errs.append(f'P{n}：標題列要寫「【P{n}】重點：一句話重點」')
        segs, prev = [], None
        for ln in blk.strip().split('\n')[1:]:
            ln = ln.strip()
            if not ln or ln.startswith('#'): continue
            h = re.match(r'^([^｜|]+)[｜|]([^｜|]*)[｜|](.*)$', ln)
            if h:
                role = h.group(1).strip()
                off = bool(re.search(r'[（(]\s*幕後\s*[）)]$', role))      # 貓（幕後）＝跳出場景的幕後解說
                role = re.sub(r'[（(]\s*幕後\s*[）)]$', '', role).strip()
                who = WHO.get(role)
                if not who: errs.append(f'P{n}：角色「{h.group(1)}」要寫 貓、機，或 貓（幕後）、機（幕後）'); who = 'robot'
                a = h.group(2).strip()
                if a == '=':
                    if prev is None: errs.append(f'P{n}：第一段不能用「=」'); at = {'home': 1}
                    else: at = dict(prev)
                elif a in ('', '家', 'home'): at = {'home': 1}
                elif a.startswith('@'):
                    try: x, y = [float(v) for v in a[1:].split(',')]; at = {'p': [x, y]}
                    except ValueError: errs.append(f'P{n}：位置「{a}」要寫成 @橫%,直%（例：@70,40）'); at = {'home': 1}
                else: at = {'q': a}
                prev = at
                segs.append({'who': who, 'at': at, 'tip': h.group(3).strip(), 't': '', **({'off': 1} if off else {})})
            elif segs: segs[-1]['t'] += ln
            else: errs.append(f'P{n}：台詞前面要先有「角色｜錨點｜泡泡」')
        for s in segs:
            if not s['t']: errs.append(f'P{n}：「{s["tip"]}」這段沒有台詞')
        pages[n] = {'key': km.group(1).strip() if km else '', 'segs': segs}
    return pages, errs


def lint(pages, deck_pages, max_sec=60):
    errs, warns = [], []
    for n, p in sorted(pages.items()):
        if not p['segs']: errs.append(f'P{n}：沒有任何對話'); continue
        if p['segs'][0]['who'] != 'cat': warns.append(f'P{n}：建議由小貓先問')
        if deck_pages is not None:
            if n > len(deck_pages): errs.append(f'P{n}：簡報只有 {len(deck_pages)} 頁'); continue
            txt = norm(deck_pages[n - 1])
            for s in p['segs']:
                q = s['at'].get('q')
                if q and norm(q) not in txt: errs.append(f'P{n}：錨點「{q}」不在這頁的文字裡（圖片頁請用 家 或 @x,y）')
        bang = sum(len(re.findall(r'[！!]', s['t'] + s['tip'])) for s in p['segs'])
        if bang > 2: warns.append(f'P{n}：驚嘆號 {bang} 個，聊天口吻偶爾用就好（一頁 2 個以內）')
        for s in p['segs']:
            t = s['t']
            if len(t) > 70: warns.append(f'P{n}：「{t[:12]}…」{len(t)} 字，字幕太長，建議拆段')
            for w in AI_TONE:
                if w in t or w in s['tip']: warns.append(f'P{n}：「{w}」口氣太像 AI，換個說法')
        sg = p['segs']
        est = sum(len(re.sub(r'\s', '', s['t'])) / CPS + pause_ms(s, sg[i + 1] if i + 1 < len(sg) else None) / 1000 for i, s in enumerate(sg))
        p['est'] = est
        if est > max_sec: errs.append(f'P{n}：估計 {est:.0f} 秒，超過 {max_sec} 秒，請刪字')
        elif est > max_sec - 5: warns.append(f'P{n}：估計 {est:.0f} 秒，實際語音常比估計多 8～15%，可能超過 {max_sec} 秒')
    return errs, warns


def load_say(path):
    rules = list(BASE_SAY)
    if path:
        for ln in open(path, encoding='utf-8-sig'):
            if '=' in ln and not ln.startswith('#'):
                a, b = ln.rstrip('\n').split('=', 1); rules.insert(0, (a, b))
    rules.sort(key=lambda r: -len(r[0]))
    return rules


async def tts(text, voice, rate, pitch, proxy, cache, sem):
    import edge_tts
    f = os.path.join(cache, hashlib.sha1(f'{voice}|{rate}|{pitch}|{text}'.encode()).hexdigest()[:16] + '.mp3')   # 換聲音／語速／音高都會重做
    if os.path.exists(f): return f
    async with sem:
        async def one():
            b = bytearray()
            async for ch in edge_tts.Communicate(text, voice, rate=rate, pitch=pitch, proxy=proxy).stream():
                if ch['type'] == 'audio': b += ch['data']
            return b
        for k in range(6):
            try:
                b = await asyncio.wait_for(one(), 60)      # 偶爾會卡住，要有逾時
                if b:
                    open(f, 'wb').write(b); print('  ok', voice[6:-6], text[:14], flush=True); return f
            except Exception as e:
                print('  retry', k + 1, type(e).__name__, flush=True)
            await asyncio.sleep(3)
    print('  失敗，稍後整批重試：', text[:20], flush=True)
    return None


async def build(pages, a):
    rules, cache = load_say(a.say), a.cache
    os.makedirs(cache, exist_ok=True)
    sem = asyncio.Semaphore(4)
    def spoken(t):
        for x, y in rules: t = t.replace(x, y)
        return t
    order = [(n, s) for n in sorted(pages) for s in pages[n]['segs']]
    print('語音段數', len(order), flush=True)
    job = lambda s: tts(spoken(s['t']), VOICE[s['who']], RATE[s['who']], pitch_of(s), a.proxy, cache, sem)
    files = await asyncio.gather(*[job(s) for _, s in order])
    for r in range(5):                                   # edge-tts 常限流（NoAudioReceived），等一下再補做失敗的段落
        bad = [i for i, f in enumerate(files) if not f]
        if not bad: break
        print(f'有 {len(bad)} 段失敗，{30 * (r + 1)} 秒後第 {r + 1} 次補做', flush=True)
        await asyncio.sleep(30 * (r + 1))
        for i, f in zip(bad, await asyncio.gather(*[job(order[i][1]) for i in bad])): files[i] = f
    if not all(files): sys.exit('仍有語音段落失敗；已完成的都在快取裡，稍後重跑同一指令即可')
    sec = lambda f: os.path.getsize(f) * 8 / 48000                         # edge-tts 預設 48kbps
    out, tot, worst = {}, 0, 0
    for k, ((n, s), f) in enumerate(zip(order, files)):
        nxt = order[k + 1][1] if k + 1 < len(order) and order[k + 1][0] == n else None
        g = pause_ms(s, nxt)
        p = out.setdefault(str(n), {'key': pages[n]['key'], 'segs': [], 'sec': 0})
        p['segs'].append({'who': s['who'], 't': s['t'], 'tip': s['tip'], 'at': s['at'], 'g': g, 'a': base64.b64encode(open(f, 'rb').read()).decode(), **({'off': 1} if s.get('off') else {})})
        p['sec'] += sec(f) + g / 1000
    for n, p in out.items():
        worst = max(worst, p['sec']); tot += p['sec'] + KEY_SEC + TURN_SEC
        print(f'P{n}: {p["sec"]:.1f} 秒' + (f'  ← 超過 {a.max_sec} 秒' if p['sec'] > a.max_sec else ''))
        p['sec'] = round(p['sec'], 1)
    json.dump({'pages': out}, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'輸出 {a.out}（{os.path.getsize(a.out) / 1e6:.1f} MB）；自動連播全部約 {int(tot // 60)} 分 {int(tot % 60)} 秒')
    if worst > a.max_sec: sys.exit(f'有頁面超過 {a.max_sec} 秒，請刪減台詞後重跑')


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    ap = argparse.ArgumentParser()
    ap.add_argument('script'); ap.add_argument('--deck'); ap.add_argument('--slide-class', default='slide')
    ap.add_argument('-o', '--out', default='duo.json'); ap.add_argument('--say')
    ap.add_argument('--proxy', default=os.environ.get('DUO_PROXY') or os.environ.get('HTTPS_PROXY') or os.environ.get('HTTP_PROXY'))
    ap.add_argument('--cache'); ap.add_argument('--check', action='store_true')
    ap.add_argument('--max-sec', type=int, default=60, help='每頁秒數上限：一般 60；L2 要帶 L3 實例時用 90')
    a = ap.parse_args()
    a.cache = a.cache or os.path.join(os.path.dirname(os.path.abspath(a.script)), 'duo_audio')
    pages, errs = parse(open(a.script, encoding='utf-8-sig').read())
    dp = slide_texts(open(a.deck, encoding='utf-8-sig').read(), a.slide_class) if a.deck else None
    e2, warns = lint(pages, dp, a.max_sec); errs = list(dict.fromkeys(errs + e2)); warns = list(dict.fromkeys(warns))
    for n, p in sorted(pages.items()):
        print(f'P{n}: {len(p["segs"])} 段，估計 {p.get("est", 0):.0f} 秒')
    tot = sum(p.get('est', 0) * 1.08 + KEY_SEC + TURN_SEC for p in pages.values())
    print(f'預估自動連播全部約 {int(tot // 60)} 分（實際語音約為估計 × 1.08）')
    for w in warns: print('提醒：', w)
    for e in errs: print('錯誤：', e)
    if errs: sys.exit(1)
    if not pages: sys.exit('對話稿裡沒有【P數字】段落')
    if a.check: print('檢查通過'); return
    asyncio.run(build(pages, a))


if __name__ == '__main__':
    main()
