"""列出 HTML 簡報每一頁的文字，供撰寫對話稿與檢查錨點。

用法：python slides_text.py deck.html [--slide-class slide]
"""
import argparse, re, sys
from html.parser import HTMLParser

VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr'}
BLOCK = {'p', 'div', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'td', 'th', 'section', 'br', 'dt', 'dd', 'figcaption', 'text'}


class _P(HTMLParser):
    def __init__(self, cls):
        super().__init__(convert_charrefs=True)
        self.cls, self.depth, self.start, self.skip = cls, 0, None, 0
        self.pages, self.buf = [], []

    def handle_starttag(self, tag, attrs):
        if tag in VOID:
            if self.start is not None and tag in BLOCK: self.buf.append('\n')
            return
        self.depth += 1
        if tag in ('script', 'style'): self.skip += 1
        c = (dict(attrs).get('class') or '').split()
        if self.start is None and self.cls in c:
            self.start, self.buf = self.depth, []
        elif self.start is not None and tag in BLOCK:
            self.buf.append('\n')

    def handle_endtag(self, tag):
        if tag in VOID: return
        if tag in ('script', 'style') and self.skip: self.skip -= 1
        if self.start is not None and self.depth == self.start:
            self.pages.append(''.join(self.buf)); self.start = None
        elif self.start is not None and tag in BLOCK:
            self.buf.append('\n')
        self.depth -= 1

    def handle_data(self, d):
        if self.start is not None and not self.skip: self.buf.append(d)


def slide_texts(html_text, cls='slide'):
    """回傳每頁文字（保留換行），頁碼＝索引＋1。"""
    p = _P(cls); p.feed(html_text); p.close()
    out = []
    for t in p.pages:
        lines = [' '.join(x.split()) for x in t.split('\n')]
        out.append('\n'.join(x for x in lines if x))
    return out


norm = lambda s: re.sub(r'\s+', '', s or '')

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    ap = argparse.ArgumentParser()
    ap.add_argument('deck'); ap.add_argument('--slide-class', default='slide')
    a = ap.parse_args()
    pages = slide_texts(open(a.deck, encoding='utf-8-sig').read(), a.slide_class)
    if not pages: sys.exit(f'找不到 class="{a.slide_class}" 的頁面，請用 --slide-class 指定')
    for i, t in enumerate(pages, 1):
        print(f'【P{i}】' + ('（沒有文字，可能是圖片頁）' if not t else ''))
        if t: print(t)
        print()
