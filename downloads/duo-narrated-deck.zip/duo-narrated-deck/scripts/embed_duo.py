"""把雙人偶旁白（程式、圖片、語音）嵌入 HTML 簡報，輸出單一檔案。可重複執行（會先移除舊的嵌入）。

用法：python embed_duo.py 簡報.html duo.json -o 輸出.html
選項：--slide .slide      每一頁的 CSS 選擇器
     --active active     目前頁面的 class（沒有就自動找畫面中央那頁）
     --next "go(cur+1)"  翻到下一頁的 JS（不給就模擬按 → 鍵）
     --home tr|tl|br|bl  人偶待命角落（預設右上）
     --bar bl|br|tl|tr   播放列位置（預設左下）
     --cards 成語卡.txt   每行「詞＝白話」，字幕講到該詞就跳出小卡
     --scroll            一路往下捲的長網頁（每個段落當一頁）：講到畫面外的重點會捲過去，連播時捲到下一段
"""
import argparse, base64, json, os, re, sys

A = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets')
BEGIN, END = '<!--DUO:BEGIN-->', '<!--DUO:END-->'


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    ap = argparse.ArgumentParser()
    ap.add_argument('deck'); ap.add_argument('duo'); ap.add_argument('-o', '--out', required=True)
    ap.add_argument('--slide', default='.slide'); ap.add_argument('--active', default='active'); ap.add_argument('--next', default='')
    ap.add_argument('--home', default='tr', choices=['tr', 'tl', 'br', 'bl']); ap.add_argument('--bar', default='bl', choices=['tr', 'tl', 'br', 'bl'])
    ap.add_argument('--cards', default=''); ap.add_argument('--scroll', action='store_true')
    a = ap.parse_args()

    html = open(a.deck, encoding='utf-8-sig').read()
    html = re.sub(re.escape(BEGIN) + r'.*?' + re.escape(END) + r'\n?', '', html, flags=re.S)
    data = json.load(open(a.duo, encoding='utf-8'))
    img = {w: 'data:image/png;base64,' + base64.b64encode(open(os.path.join(A, w + '.png'), 'rb').read()).decode() for w in ('cat', 'robot')}
    cfg = {'slide': a.slide, 'active': a.active, 'next': a.next, 'home': a.home, 'bar': a.bar, 'scroll': a.scroll}
    if a.cards:
        cards = {}
        for ln in open(a.cards, encoding='utf-8-sig'):
            ln = ln.strip()
            if ln and not ln.startswith('#') and '＝' in ln:
                k, v = ln.split('＝', 1); cards[k.strip()] = v.strip()
        cfg['cards'] = cards
    js_safe = lambda o: json.dumps(o, ensure_ascii=False).replace('</', '<\\/')
    block = (BEGIN + '<style>' + open(os.path.join(A, 'duo.css'), encoding='utf-8-sig').read() + '</style>'
             + f'<script>window.DUO_CFG={js_safe(cfg)};window.DUO_IMG={js_safe(img)};window.DUO_DATA={js_safe(data)};</script>'
             + '<script>' + open(os.path.join(A, 'duo.js'), encoding='utf-8-sig').read() + '</script>' + END)
    i = html.lower().rfind('</body>')
    html = html[:i] + block + '\n' + html[i:] if i >= 0 else html + block
    open(a.out, 'w', encoding='utf-8').write(html)
    print(f'輸出 {a.out}（{os.path.getsize(a.out) / 1e6:.1f} MB），共 {len(data.get("pages", {}))} 頁有對話')


if __name__ == '__main__':
    main()
